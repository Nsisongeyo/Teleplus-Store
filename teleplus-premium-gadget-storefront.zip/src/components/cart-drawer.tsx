"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { X, Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useCartStore } from "@/store/cart";
import { formatNaira } from "@/lib/format";

export default function CartDrawer() {
  const [mounted, setMounted] = useState(false);
  const isOpen = useCartStore((s) => s.isOpen);
  const close = useCartStore((s) => s.close);
  const items = useCartStore((s) => s.items);
  const updateQty = useCartStore((s) => s.updateQty);
  const removeItem = useCartStore((s) => s.removeItem);
  const subtotal = useCartStore((s) => s.subtotal());

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  if (!mounted) return null;

  return (
    <>
      <div
        className={`fixed inset-0 z-50 bg-black/40 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onClick={close}
      />
      <aside
        className={`fixed right-0 top-0 z-50 flex h-dvh w-full max-w-md flex-col bg-white shadow-2xl transition-transform duration-300 ease-[cubic-bezier(.16,1,.3,1)] ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">
          <h2 className="font-display text-lg font-semibold">Your Bag ({items.length})</h2>
          <button
            onClick={close}
            className="grid h-9 w-9 place-items-center rounded-full text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
            aria-label="Close cart"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
            <div className="grid h-16 w-16 place-items-center rounded-full bg-[#1881a2]/10 text-[#1881a2]">
              <ShoppingBag className="h-7 w-7" />
            </div>
            <p className="font-display text-base font-semibold text-slate-800">Your bag is empty</p>
            <p className="text-sm text-slate-500">Add laptops, phones or accessories to get started.</p>
            <button
              onClick={close}
              className="mt-2 rounded-full bg-[#1881a2] px-6 py-2.5 text-sm font-medium text-white transition hover:bg-[#106680]"
            >
              Continue shopping
            </button>
          </div>
        ) : (
          <>
            <div className="side-scroll flex-1 overflow-y-auto px-6 py-4">
              <ul className="flex flex-col gap-5">
                {items.map((item) => (
                  <li key={item.productId} className="flex gap-4 animate-fade-in-up">
                    <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl bg-slate-100">
                      <Image src={item.image} alt={item.name} fill className="object-cover" sizes="80px" />
                    </div>
                    <div className="flex flex-1 flex-col justify-between">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <Link
                            href={`/product/${item.slug}`}
                            onClick={close}
                            className="line-clamp-2 text-sm font-medium text-slate-900 hover:text-[#1881a2]"
                          >
                            {item.name}
                          </Link>
                          <p className="mt-0.5 text-xs text-slate-500">{item.vendorName}</p>
                        </div>
                        <button
                          onClick={() => removeItem(item.productId)}
                          className="shrink-0 text-slate-400 transition hover:text-red-500"
                          aria-label="Remove item"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 rounded-full border border-slate-200 px-1 py-1">
                          <button
                            onClick={() => updateQty(item.productId, item.qty - 1)}
                            className="grid h-6 w-6 place-items-center rounded-full text-slate-600 hover:bg-slate-100"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="w-4 text-center text-xs font-medium">{item.qty}</span>
                          <button
                            onClick={() => updateQty(item.productId, item.qty + 1)}
                            className="grid h-6 w-6 place-items-center rounded-full text-slate-600 hover:bg-slate-100"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                        <p className="text-sm font-semibold text-slate-900">
                          {formatNaira(item.price * item.qty)}
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="border-t border-slate-100 px-6 py-5">
              <div className="mb-4 flex items-center justify-between text-sm text-slate-600">
                <span>Subtotal</span>
                <span className="font-display text-base font-semibold text-slate-900">
                  {formatNaira(subtotal)}
                </span>
              </div>
              <p className="mb-4 text-xs text-slate-400">Shipping & taxes calculated at checkout.</p>
              <Link
                href="/checkout"
                onClick={close}
                className="block w-full rounded-full bg-[#1881a2] py-3.5 text-center text-sm font-semibold text-white shadow-lg shadow-[#1881a2]/25 transition hover:bg-[#106680]"
              >
                Checkout
              </Link>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
