"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { SlidersHorizontal, PackageSearch } from "lucide-react";
import ProductCard, { type ProductCardData } from "@/components/product-card";

const SORT_OPTIONS = [
  { value: "relevance", label: "Featured" },
  { value: "newest", label: "Newest" },
  { value: "bestseller", label: "Best Selling" },
  { value: "rating", label: "Top Rated" },
  { value: "price_asc", label: "Price: Low to High" },
  { value: "price_desc", label: "Price: High to Low" },
];

export default function ProductFeed() {
  const searchParams = useSearchParams();
  const [products, setProducts] = useState<ProductCardData[]>([]);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [sort, setSort] = useState("relevance");
  const sentinelRef = useRef<HTMLDivElement>(null);
  const loadingRef = useRef(false);

  const category = searchParams.get("category") || "";
  const q = searchParams.get("q") || "";
  const brand = searchParams.get("brand") || "";

  const fetchProducts = useCallback(
    async (targetPage: number, replace: boolean) => {
      if (loadingRef.current) return;
      loadingRef.current = true;
      setLoading(true);
      const params = new URLSearchParams();
      if (category) params.set("category", category);
      if (brand) params.set("brand", brand);
      if (q) params.set("q", q);
      if (sort) params.set("sort", sort);
      params.set("page", String(targetPage));
      params.set("limit", "12");

      const res = await fetch(`/api/products?${params.toString()}`);
      const data = await res.json();

      setProducts((prev) => (replace ? data.products : [...prev, ...data.products]));
      setHasMore(data.hasMore);
      setTotal(data.total);
      setPage(targetPage);
      setLoading(false);
      loadingRef.current = false;
    },
    [category, brand, q, sort],
  );

  useEffect(() => {
    fetchProducts(0, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category, brand, q, sort]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loadingRef.current) {
          fetchProducts(page + 1, false);
        }
      },
      { rootMargin: "600px" },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [page, hasMore, fetchProducts]);

  const heading = q ? `Results for "${q}"` : category ? category.charAt(0).toUpperCase() + category.slice(1) : "All Products";

  return (
    <div className="flex flex-col gap-6 px-4 pb-24 pt-6 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-bold text-slate-900 sm:text-2xl">{heading}</h1>
          <p className="text-sm text-slate-500">{total} products found</p>
        </div>
        <div className="flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-2 text-sm text-slate-600 shadow-sm">
          <SlidersHorizontal className="h-4 w-4 text-slate-400" />
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="bg-transparent text-sm font-medium text-slate-700 outline-none"
          >
            {SORT_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {products.length === 0 && !loading ? (
        <div className="flex flex-col items-center justify-center gap-3 rounded-3xl border border-dashed border-slate-300 py-24 text-center">
          <PackageSearch className="h-10 w-10 text-slate-300" />
          <p className="font-display text-lg font-semibold text-slate-700">No products found</p>
          <p className="text-sm text-slate-500">Try adjusting your search or filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-5 xl:grid-cols-4">
          {products.map((p, idx) => (
            <div key={p.id} className="animate-fade-in-up" style={{ animationDelay: `${(idx % 12) * 30}ms` }}>
              <ProductCard product={p} />
            </div>
          ))}
          {loading &&
            Array.from({ length: 8 }).map((_, i) => (
              <div key={`skeleton-${i}`} className="flex flex-col gap-3">
                <div className="skeleton aspect-square rounded-3xl" />
                <div className="skeleton h-3 w-2/3 rounded-full" />
                <div className="skeleton h-4 w-full rounded-full" />
              </div>
            ))}
        </div>
      )}

      <div ref={sentinelRef} className="h-1 w-full" />
      {!hasMore && products.length > 0 && (
        <p className="py-8 text-center text-sm text-slate-400">
          You&apos;ve reached the end — that&apos;s every product we&apos;ve got for now ✨
        </p>
      )}
    </div>
  );
}
