"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Sparkles, ShoppingBag, ArrowRight } from "lucide-react";
import { useCartStore } from "@/store/cart";
import { formatNaira } from "@/lib/format";
import { getVisitorId } from "@/lib/visitor";

type RecProduct = {
  id: number;
  name: string;
  slug: string;
  brand: string;
  images: string[] | null;
  price: string;
  rating: string | null;
  reviewCount: number;
};

export default function RightSidebar() {
  const [mounted, setMounted] = useState(false);
  const items = useCartStore((s) => s.items);
  const subtotal = useCartStore((s) => s.subtotal());
  const openCart = useCartStore((s) => s.open);
  const [recs, setRecs] = useState<RecProduct[]>([]);
  const [personalized, setPersonalized] = useState(false);

  useEffect(() => {
    setMounted(true);
    const visitorId = getVisitorId();
    fetch(`/api/recommendations?visitorId=${visitorId}&limit=6`)
      .then((r) => r.json())
      .then((data) => {
        setRecs(data.products || []);
        setPersonalized(data.personalized);
      })
      .catch(() => {});
  }, []);

  return (
    <div className="flex flex-col gap-6 px-5 py-8">
      <div className="rounded-2xl border border-slate-200 bg-white p-5">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display text-sm font-bold text-slate-900">Your Bag</h3>
          <ShoppingBag className="h-4 w-4 text-slate-400" />
        </div>
        {!mounted || items.length === 0 ? (
          <p className="text-xs text-slate-500">Nothing in your bag yet. Start adding your favorite gadgets!</p>
        ) : (
          <>
            <ul className="mb-3 flex flex-col gap-2.5">
              {items.slice(0, 3).map((item) => (
                <li key={item.productId} className="flex items-center gap-2.5">
                  <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                    <Image src={item.image} alt={item.name} fill className="object-cover" sizes="40px" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-medium text-slate-800">{item.name}</p>
                    <p className="text-[11px] text-slate-400">Qty {item.qty}</p>
                  </div>
                </li>
              ))}
            </ul>
            {items.length > 3 && <p className="mb-3 text-xs text-slate-400">+{items.length - 3} more item(s)</p>}
            <div className="mb-3 flex items-center justify-between text-sm">
              <span className="text-slate-500">Subtotal</span>
              <span className="font-display font-bold text-slate-900">{formatNaira(subtotal)}</span>
            </div>
            <button
              onClick={openCart}
              className="flex w-full items-center justify-center gap-1.5 rounded-full bg-[#1881a2] py-2.5 text-xs font-semibold text-white transition hover:bg-[#106680]"
            >
              View Bag <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </>
        )}
      </div>

      {recs.length > 0 && (
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="mb-3 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-[#1881a2]" />
            <h3 className="font-display text-sm font-bold text-slate-900">
              {personalized ? "Picked for you" : "Trending now"}
            </h3>
          </div>
          <ul className="flex flex-col gap-3">
            {recs.map((p) => (
              <li key={p.id}>
                <Link href={`/product/${p.slug}`} className="group flex items-center gap-3">
                  <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                    <Image src={p.images?.[0] || "/images/hero-devices.jpg"} alt={p.name} fill className="object-cover transition group-hover:scale-105" sizes="56px" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-medium text-slate-800 group-hover:text-[#1881a2]">{p.name}</p>
                    <p className="text-xs font-bold text-slate-900">{formatNaira(Number(p.price))}</p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
          {personalized && (
            <p className="mt-3 text-[11px] leading-relaxed text-slate-400">
              Curated from your recent views &amp; clicks ✨
            </p>
          )}
        </div>
      )}

      <div className="rounded-2xl bg-slate-900 p-5 text-white">
        <p className="font-display text-sm font-bold">Need help deciding?</p>
        <p className="mt-1 text-xs text-white/70">Chat with our team on WhatsApp for instant recommendations.</p>
        <a
          href={`https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}?text=${encodeURIComponent("Hi Teleplus Store, I need help choosing a product.")}`}
          target="_blank"
          rel="noreferrer"
          className="mt-3 flex items-center justify-center gap-1.5 rounded-full bg-[#25D366] py-2.5 text-xs font-semibold text-white transition hover:brightness-95"
        >
          Chat on WhatsApp
        </a>
      </div>
    </div>
  );
}
