"use client";

import Link from "next/link";
import { useSearchParams, usePathname } from "next/navigation";
import { Laptop, Smartphone, Headphones, LayoutGrid, Sparkles, TrendingUp, Tag, Store } from "lucide-react";

type Category = { id: number; name: string; slug: string; icon: string | null };

const ICONS: Record<string, React.ElementType> = {
  laptop: Laptop,
  smartphone: Smartphone,
  headphones: Headphones,
};

const BRANDS = ["Novaris", "Solstice", "AeroTech", "Novacore", "Auralite", "VoltBox", "GuardianGear", "Visionary"];
const PRICE_RANGES = [
  { label: "Under ₦50k", min: "0", max: "50000" },
  { label: "₦50k – ₦300k", min: "50000", max: "300000" },
  { label: "₦300k – ₦1M", min: "300000", max: "1000000" },
  { label: "Above ₦1M", min: "1000000", max: "" },
];

export default function LeftSidebar({ categories }: { categories: Category[] }) {
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const activeCategory = searchParams.get("category") || "";
  const activeBrand = searchParams.get("brand") || "";
  const activeSort = searchParams.get("sort") || "";
  const minPrice = searchParams.get("minPrice") || "";

  function buildHref(updates: Record<string, string | null>) {
    const params = new URLSearchParams(searchParams.toString());
    Object.entries(updates).forEach(([key, value]) => {
      if (value) params.set(key, value);
      else params.delete(key);
    });
    return `${pathname}?${params.toString()}`;
  }

  return (
    <nav className="flex flex-col gap-8 px-5 py-8">
      <div>
        <p className="mb-3 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400">Shop</p>
        <ul className="flex flex-col gap-1">
          <li>
            <Link
              href={buildHref({ category: null })}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                !activeCategory ? "bg-[#1881a2]/10 text-[#1881a2]" : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              <LayoutGrid className="h-4 w-4" /> All Products
            </Link>
          </li>
          {categories.map((cat) => {
            const Icon = ICONS[cat.icon || ""] || LayoutGrid;
            const active = activeCategory === cat.slug;
            return (
              <li key={cat.id}>
                <Link
                  href={buildHref({ category: cat.slug })}
                  className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                    active ? "bg-[#1881a2]/10 text-[#1881a2]" : "text-slate-600 hover:bg-slate-100"
                  }`}
                >
                  <Icon className="h-4 w-4" /> {cat.name}
                </Link>
              </li>
            );
          })}
        </ul>
      </div>

      <div>
        <p className="mb-3 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400">Discover</p>
        <ul className="flex flex-col gap-1">
          <li>
            <Link
              href={buildHref({ sort: "newest" })}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                activeSort === "newest" ? "bg-[#1881a2]/10 text-[#1881a2]" : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              <Sparkles className="h-4 w-4" /> New Arrivals
            </Link>
          </li>
          <li>
            <Link
              href={buildHref({ sort: "bestseller" })}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                activeSort === "bestseller" ? "bg-[#1881a2]/10 text-[#1881a2]" : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              <TrendingUp className="h-4 w-4" /> Best Sellers
            </Link>
          </li>
        </ul>
      </div>

      <div>
        <p className="mb-3 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400">Price</p>
        <ul className="flex flex-col gap-1">
          {PRICE_RANGES.map((range) => (
            <li key={range.label}>
              <Link
                href={buildHref({ minPrice: range.min || null, maxPrice: range.max || null })}
                className={`flex items-center gap-2 rounded-xl px-3 py-2 text-sm transition ${
                  minPrice === range.min ? "bg-[#1881a2]/10 text-[#1881a2] font-medium" : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <Tag className="h-3.5 w-3.5" /> {range.label}
              </Link>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <p className="mb-3 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400">Brands</p>
        <div className="flex flex-wrap gap-1.5 px-1">
          {BRANDS.map((b) => (
            <Link
              key={b}
              href={buildHref({ brand: activeBrand === b ? null : b })}
              className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                activeBrand === b
                  ? "border-[#1881a2] bg-[#1881a2] text-white"
                  : "border-slate-200 text-slate-600 hover:border-slate-300"
              }`}
            >
              {b}
            </Link>
          ))}
        </div>
      </div>

      <Link
        href="/sell"
        className="group flex flex-col gap-2 rounded-2xl bg-gradient-to-br from-[#1881a2] to-[#0b4e63] p-5 text-white shadow-lg shadow-[#1881a2]/20 transition hover:shadow-xl"
      >
        <Store className="h-5 w-5" />
        <p className="font-display text-sm font-bold">Sell on Teleplus</p>
        <p className="text-xs text-white/80">Join our marketplace and reach thousands of gadget lovers.</p>
        <span className="mt-1 inline-flex w-fit items-center gap-1 text-xs font-semibold underline-offset-2 group-hover:underline">
          Get started →
        </span>
      </Link>
    </nav>
  );
}
