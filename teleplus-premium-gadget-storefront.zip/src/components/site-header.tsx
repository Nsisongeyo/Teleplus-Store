"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Search, ShoppingBag, Menu, X, Store, LayoutDashboard, Sparkles } from "lucide-react";
import { useCartStore } from "@/store/cart";

export default function SiteHeader() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [mounted, setMounted] = useState(false);
  const [query, setQuery] = useState(searchParams.get("q") || "");
  const [bizOpen, setBizOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const bizRef = useRef<HTMLDivElement>(null);
  const count = useCartStore((s) => s.count());
  const openCart = useCartStore((s) => s.open);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (bizRef.current && !bizRef.current.contains(e.target as Node)) setBizOpen(false);
    }
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams(searchParams.toString());
    if (query) params.set("q", query);
    else params.delete("q");
    router.push(`/?${params.toString()}`);
  }

  const isAdminOrVendor = pathname?.startsWith("/admin") || pathname?.startsWith("/vendor");
  if (isAdminOrVendor) return null;

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-[1600px] items-center gap-4 px-4 sm:px-6">
        <Link href="/" className="flex shrink-0 items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-[#1881a2] font-display text-sm font-bold text-white">
            T+
          </span>
          <span className="font-display text-lg font-bold tracking-tight text-slate-900 max-[420px]:hidden">
            Teleplus
          </span>
        </Link>

        <form onSubmit={handleSearch} className="relative mx-auto w-full max-w-xl flex-1">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            type="search"
            placeholder="Search laptops, phones, accessories..."
            className="w-full rounded-full border border-slate-200 bg-slate-50 py-2.5 pl-11 pr-4 text-sm text-slate-800 outline-none transition focus:border-[#1881a2] focus:bg-white focus:ring-4 focus:ring-[#1881a2]/10"
          />
        </form>

        <div className="hidden shrink-0 items-center gap-1 md:flex">
          <Link
            href="/vendors"
            className="rounded-full px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
          >
            Marketplace
          </Link>
          <Link
            href="/sell"
            className="rounded-full px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
          >
            Sell on Teleplus
          </Link>
          <div className="relative" ref={bizRef}>
            <button
              onClick={() => setBizOpen((v) => !v)}
              className="rounded-full px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
            >
              Business
            </button>
            {bizOpen && (
              <div className="absolute right-0 top-full mt-2 w-52 animate-fade-in-up rounded-2xl border border-slate-100 bg-white p-2 shadow-xl">
                <Link
                  href="/admin/login"
                  className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50"
                >
                  <LayoutDashboard className="h-4 w-4 text-[#1881a2]" /> Admin Panel
                </Link>
                <Link
                  href="/vendor/login"
                  className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50"
                >
                  <Store className="h-4 w-4 text-[#1881a2]" /> Vendor Login
                </Link>
                <Link
                  href="/vendor/register"
                  className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50"
                >
                  <Sparkles className="h-4 w-4 text-[#1881a2]" /> Become a Vendor
                </Link>
              </div>
            )}
          </div>
        </div>

        <button
          onClick={openCart}
          className="relative grid h-10 w-10 shrink-0 place-items-center rounded-full text-slate-700 transition hover:bg-slate-100"
          aria-label="Open cart"
        >
          <ShoppingBag className="h-5 w-5" />
          {mounted && count > 0 && (
            <span className="absolute -right-0.5 -top-0.5 grid h-5 w-5 animate-pop place-items-center rounded-full bg-[#1881a2] text-[10px] font-bold text-white">
              {count > 9 ? "9+" : count}
            </span>
          )}
        </button>

        <button
          onClick={() => setMobileOpen((v) => !v)}
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-slate-700 hover:bg-slate-100 md:hidden"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="flex flex-col gap-1 border-t border-slate-100 bg-white px-4 py-3 md:hidden">
          <Link href="/vendors" className="rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50">
            Marketplace
          </Link>
          <Link href="/sell" className="rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50">
            Sell on Teleplus
          </Link>
          <Link href="/admin/login" className="rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50">
            Admin Panel
          </Link>
          <Link href="/vendor/login" className="rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50">
            Vendor Login
          </Link>
        </div>
      )}
    </header>
  );
}
