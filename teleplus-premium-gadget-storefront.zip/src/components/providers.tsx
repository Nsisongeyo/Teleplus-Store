"use client";

import { useEffect, type ReactNode } from "react";
import { getVisitorId } from "@/lib/visitor";

export default function Providers({ children }: { children: ReactNode }) {
  useEffect(() => {
    getVisitorId();
  }, []);

  return <>{children}</>;
}
