"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { Heart, ShoppingBag } from "lucide-react";
import StarRating from "./star-rating";
import { formatNaira } from "@/lib/format";
import { useCartStore } from "@/store/cart";
import { track } from "@/lib/visitor";

export type ProductCardData = {
  id: number;
  name: string;
  slug: string;
  brand: string;
  shortDescription?: string | null;
  images: string[] | null;
  price: string;
  compareAtPrice: string | null;
  stock?: number;
  rating: string | null;
  reviewCount: number;
  soldCount?: number;
  isFeatured?: boolean;
  categoryId?: number | null;
  categoryName?: string | null;
  vendorId?: number;
  vendorName?: string | null;
};

export default function ProductCard({ product }: { product: ProductCardData }) {
  const [liked, setLiked] = useState(false);
  const addItem = useCartStore((s) => s.addItem);
  const price = Number(product.price);
  const compareAt = product.compareAtPrice ? Number(product.compareAtPrice) : null;
  const discount = compareAt ? Math.round(((compareAt - price) / compareAt) * 100) : 0;
  const image = product.images?.[0] || "/images/hero-devices.jpg";

  function handleAdd(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image,
      price,
      vendorId: product.vendorId || 1,
      vendorName: product.vendorName || "Teleplus Store",
      stock: product.stock ?? 99,
    });
    track("add_to_cart", { productId: product.id, categoryId: product.categoryId ?? undefined, brand: product.brand });
  }

  function handleClick() {
    track("click", { productId: product.id, categoryId: product.categoryId ?? undefined, brand: product.brand });
  }

  return (
    <Link
      href={`/product/${product.slug}`}
      onClick={handleClick}
      className="group relative flex flex-col overflow-hidden rounded-3xl border border-slate-200/70 bg-white transition-all duration-300 hover:-translate-y-1 hover:border-slate-300 hover:shadow-[0_20px_45px_rgba(15,35,45,0.12)]"
    >
      <div className="relative aspect-square w-full overflow-hidden bg-slate-50">
        <Image
          src={image}
          alt={product.name}
          fill
          sizes="(max-width: 768px) 50vw, 280px"
          className="object-cover transition-transform duration-500 group-hover:scale-[1.06]"
        />
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {discount > 0 && (
            <span className="rounded-full bg-red-500 px-2.5 py-1 text-[10px] font-bold text-white shadow-sm">
              -{discount}%
            </span>
          )}
          {product.isFeatured && (
            <span className="rounded-full bg-[#1881a2] px-2.5 py-1 text-[10px] font-bold text-white shadow-sm">
              Featured
            </span>
          )}
        </div>
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            setLiked((v) => !v);
            track("wishlist", { productId: product.id, categoryId: product.categoryId ?? undefined, brand: product.brand });
          }}
          className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-white/90 text-slate-500 opacity-0 shadow-sm backdrop-blur transition-all duration-300 group-hover:opacity-100 hover:text-red-500"
          aria-label="Save"
        >
          <Heart className={`h-4 w-4 ${liked ? "fill-red-500 text-red-500" : ""}`} />
        </button>

        <button
          onClick={handleAdd}
          className="absolute inset-x-3 bottom-3 flex translate-y-3 items-center justify-center gap-1.5 rounded-full bg-slate-900/90 py-2.5 text-xs font-semibold text-white opacity-0 backdrop-blur transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 hover:bg-[#1881a2]"
        >
          <ShoppingBag className="h-3.5 w-3.5" /> Quick Add
        </button>
      </div>

      <div className="flex flex-1 flex-col gap-1.5 p-4">
        <p className="text-[11px] font-medium uppercase tracking-wide text-slate-400">{product.brand}</p>
        <h3 className="line-clamp-2 font-display text-sm font-semibold leading-snug text-slate-900">
          {product.name}
        </h3>
        {Number(product.reviewCount) > 0 && (
          <StarRating rating={Number(product.rating || 0)} count={product.reviewCount} size={12} />
        )}
        <div className="mt-auto flex items-baseline gap-2 pt-1.5">
          <span className="font-display text-base font-bold text-slate-900">{formatNaira(price)}</span>
          {compareAt && compareAt > price && (
            <span className="text-xs text-slate-400 line-through">{formatNaira(compareAt)}</span>
          )}
        </div>
      </div>
    </Link>
  );
}
