"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function VendorStatusActions({ vendorId, status }: { vendorId: number; status: string }) {
  const router = useRouter();
  const [saving, setSaving] = useState(false);

  async function updateStatus(newStatus: string) {
    setSaving(true);
    await fetch(`/api/admin/vendors/${vendorId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });
    router.refresh();
    setSaving(false);
  }

  return (
    <div className="flex gap-2">
      {status !== "approved" && (
        <button
          disabled={saving}
          onClick={() => updateStatus("approved")}
          className="rounded-full bg-emerald-100 px-3 py-1.5 text-xs font-semibold text-emerald-700 disabled:opacity-50"
        >
          Approve
        </button>
      )}
      {status !== "suspended" && (
        <button
          disabled={saving}
          onClick={() => updateStatus("suspended")}
          className="rounded-full bg-red-100 px-3 py-1.5 text-xs font-semibold text-red-600 disabled:opacity-50"
        >
          Suspend
        </button>
      )}
    </div>
  );
}
