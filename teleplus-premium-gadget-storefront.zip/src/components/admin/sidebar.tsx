"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, Package, ShoppingCart, Store, LogOut, ExternalLink } from "lucide-react";

const LINKS = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/orders", label: "Orders", icon: ShoppingCart },
  { href: "/admin/vendors", label: "Vendors", icon: Store },
];

export default function AdminSidebar({ name }: { name: string }) {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    await fetch("/api/auth/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <aside className="flex h-dvh w-64 shrink-0 flex-col border-r border-slate-800 bg-slate-950 text-slate-300">
      <div className="flex items-center gap-2 border-b border-slate-800 px-6 py-5">
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-[#1881a2] font-display text-sm font-bold text-white">
          T+
        </span>
        <div>
          <p className="font-display text-sm font-bold text-white">Teleplus</p>
          <p className="text-[11px] text-slate-500">Admin Panel</p>
        </div>
      </div>

      <nav className="flex flex-1 flex-col gap-1 px-4 py-6">
        {LINKS.map((link) => {
          const active = pathname === link.href;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition ${
                active ? "bg-[#1881a2] text-white" : "hover:bg-slate-900 hover:text-white"
              }`}
            >
              <link.icon className="h-4 w-4" /> {link.label}
            </Link>
          );
        })}
        <Link
          href="/"
          target="_blank"
          className="mt-4 flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium text-slate-400 hover:bg-slate-900 hover:text-white"
        >
          <ExternalLink className="h-4 w-4" /> View Storefront
        </Link>
      </nav>

      <div className="border-t border-slate-800 p-4">
        <p className="truncate px-2 text-xs text-slate-500">Signed in as {name}</p>
        <button
          onClick={handleLogout}
          className="mt-2 flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium text-slate-400 hover:bg-slate-900 hover:text-white"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>
    </aside>
  );
}
