"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2 } from "lucide-react";

const PRESET_IMAGES = [
  "/images/products/laptop-slate.jpg",
  "/images/products/laptop-pro.jpg",
  "/images/products/laptop-gaming.jpg",
  "/images/products/phone-flagship.jpg",
  "/images/products/phone-flagship-back.jpg",
  "/images/products/phone-budget.jpg",
  "/images/products/earbuds.jpg",
  "/images/products/smartwatch.jpg",
  "/images/products/accessories-flatlay.jpg",
  "/images/hero-devices.jpg",
];

type Category = { id: number; name: string };
type Vendor = { id: number; name: string };

export type ProductFormValues = {
  name: string;
  brand: string;
  categoryId: number | null;
  vendorId?: number;
  shortDescription: string;
  description: string;
  price: string;
  compareAtPrice: string;
  stock: string;
  status: string;
  isFeatured: boolean;
  images: string[];
  specs: Record<string, string>;
  tags: string[];
};

export default function ProductForm({
  categories,
  vendors,
  initialData,
  apiEndpoint,
  method,
  redirectTo,
  showStatusControl = true,
}: {
  categories: Category[];
  vendors?: Vendor[];
  initialData?: Partial<ProductFormValues>;
  apiEndpoint: string;
  method: "POST" | "PUT";
  redirectTo: string;
  showStatusControl?: boolean;
}) {
  const router = useRouter();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState<ProductFormValues>({
    name: initialData?.name || "",
    brand: initialData?.brand || "",
    categoryId: initialData?.categoryId ?? categories[0]?.id ?? null,
    vendorId: initialData?.vendorId ?? vendors?.[0]?.id,
    shortDescription: initialData?.shortDescription || "",
    description: initialData?.description || "",
    price: initialData?.price || "",
    compareAtPrice: initialData?.compareAtPrice || "",
    stock: initialData?.stock || "10",
    status: initialData?.status || "live",
    isFeatured: initialData?.isFeatured || false,
    images: initialData?.images?.length ? initialData.images : [PRESET_IMAGES[0]],
    specs: initialData?.specs || { Processor: "", RAM: "", Storage: "" },
    tags: initialData?.tags || [],
  });
  const [tagInput, setTagInput] = useState(form.tags.join(", "));

  function toggleImage(url: string) {
    setForm((f) => ({
      ...f,
      images: f.images.includes(url) ? f.images.filter((i) => i !== url) : [...f.images, url],
    }));
  }

  function updateSpec(key: string, value: string) {
    setForm((f) => ({ ...f, specs: { ...f.specs, [key]: value } }));
  }

  function addSpecRow() {
    setForm((f) => ({ ...f, specs: { ...f.specs, [`Spec ${Object.keys(f.specs).length + 1}`]: "" } }));
  }

  function removeSpecRow(key: string) {
    setForm((f) => {
      const specs = { ...f.specs };
      delete specs[key];
      return { ...f, specs };
    });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const res = await fetch(apiEndpoint, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          tags: tagInput.split(",").map((t) => t.trim()).filter(Boolean),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong");
      router.push(redirectTo);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      <div className="grid grid-cols-1 gap-5 rounded-2xl border border-slate-200 bg-white p-6 sm:grid-cols-2">
        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label className="text-xs font-semibold text-slate-500">Product Name</label>
          <input
            required
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500">Brand</label>
          <input
            required
            value={form.brand}
            onChange={(e) => setForm((f) => ({ ...f, brand: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500">Category</label>
          <select
            value={form.categoryId ?? ""}
            onChange={(e) => setForm((f) => ({ ...f, categoryId: Number(e.target.value) }))}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          >
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        {vendors && (
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Vendor</label>
            <select
              value={form.vendorId}
              onChange={(e) => setForm((f) => ({ ...f, vendorId: Number(e.target.value) }))}
              className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
            >
              {vendors.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name}
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500">Price (₦)</label>
          <input
            required
            type="number"
            value={form.price}
            onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500">Compare-at Price (₦, optional)</label>
          <input
            type="number"
            value={form.compareAtPrice}
            onChange={(e) => setForm((f) => ({ ...f, compareAtPrice: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500">Stock</label>
          <input
            required
            type="number"
            value={form.stock}
            onChange={(e) => setForm((f) => ({ ...f, stock: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
        </div>

        {showStatusControl && (
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Status</label>
            <select
              value={form.status}
              onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
              className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
            >
              <option value="live">Live</option>
              <option value="pending">Pending</option>
              <option value="draft">Draft</option>
            </select>
          </div>
        )}

        <div className="flex items-center gap-2 sm:col-span-2">
          <input
            id="featured"
            type="checkbox"
            checked={form.isFeatured}
            onChange={(e) => setForm((f) => ({ ...f, isFeatured: e.target.checked }))}
            className="h-4 w-4 accent-[#1881a2]"
          />
          <label htmlFor="featured" className="text-sm text-slate-600">
            Mark as featured
          </label>
        </div>

        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label className="text-xs font-semibold text-slate-500">Short Description</label>
          <input
            value={form.shortDescription}
            onChange={(e) => setForm((f) => ({ ...f, shortDescription: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
        </div>
        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label className="text-xs font-semibold text-slate-500">Full Description</label>
          <textarea
            rows={4}
            value={form.description}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
        </div>
        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label className="text-xs font-semibold text-slate-500">Tags (comma separated)</label>
          <input
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6">
        <p className="mb-3 text-xs font-semibold text-slate-500">Product Images (click to select)</p>
        <div className="grid grid-cols-4 gap-3 sm:grid-cols-5">
          {PRESET_IMAGES.map((img) => (
            <button
              type="button"
              key={img}
              onClick={() => toggleImage(img)}
              className={`relative aspect-square overflow-hidden rounded-xl border-2 ${
                form.images.includes(img) ? "border-[#1881a2]" : "border-transparent"
              }`}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={img} alt="preset" className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6">
        <div className="mb-3 flex items-center justify-between">
          <p className="text-xs font-semibold text-slate-500">Specifications</p>
          <button type="button" onClick={addSpecRow} className="flex items-center gap-1 text-xs font-semibold text-[#1881a2]">
            <Plus className="h-3.5 w-3.5" /> Add Row
          </button>
        </div>
        <div className="flex flex-col gap-2">
          {Object.entries(form.specs).map(([key, value]) => (
            <div key={key} className="flex items-center gap-2">
              <input
                value={key}
                onChange={(e) => {
                  const newSpecs = { ...form.specs };
                  delete newSpecs[key];
                  newSpecs[e.target.value] = value;
                  setForm((f) => ({ ...f, specs: newSpecs }));
                }}
                className="w-1/3 rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-[#1881a2]"
              />
              <input
                value={value}
                onChange={(e) => updateSpec(key, e.target.value)}
                className="flex-1 rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-[#1881a2]"
              />
              <button type="button" onClick={() => removeSpecRow(key)} className="text-slate-400 hover:text-red-500">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {error && <p className="text-sm font-medium text-red-500">{error}</p>}

      <button
        disabled={submitting}
        className="w-fit rounded-full bg-[#1881a2] px-8 py-3.5 text-sm font-semibold text-white transition hover:bg-[#106680] disabled:opacity-50"
      >
        {submitting ? "Saving..." : "Save Product"}
      </button>
    </form>
  );
}
