"use client";

import { useEffect } from "react";
import { track } from "@/lib/visitor";

export default function ViewTracker({
  productId,
  categoryId,
  brand,
}: {
  productId: number;
  categoryId: number | null;
  brand: string;
}) {
  useEffect(() => {
    track("view", { productId, categoryId: categoryId ?? undefined, brand });
  }, [productId, categoryId, brand]);

  return null;
}
