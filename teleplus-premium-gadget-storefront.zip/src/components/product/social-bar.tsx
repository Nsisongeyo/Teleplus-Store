"use client";

import { useEffect, useMemo, useState } from "react";
import { Heart, Share2, Eye, MessageCircle } from "lucide-react";
import { track } from "@/lib/visitor";

export default function SocialBar({
  productId,
  categoryId,
  brand,
  soldCount,
  reviewCount,
}: {
  productId: number;
  categoryId?: number | null;
  brand: string;
  soldCount: number;
  reviewCount: number;
}) {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [viewers, setViewers] = useState(0);
  const [copied, setCopied] = useState(false);

  const baseLikes = useMemo(() => Math.max(12, Math.round(soldCount * 0.6) + reviewCount * 3), [soldCount, reviewCount]);

  useEffect(() => {
    setLikeCount(baseLikes);
    setViewers(6 + (productId % 19));
    const interval = setInterval(() => {
      setViewers((v) => Math.max(3, v + (Math.random() > 0.5 ? 1 : -1)));
    }, 4000);
    return () => clearInterval(interval);
  }, [baseLikes, productId]);

  function toggleLike() {
    setLiked((v) => {
      const next = !v;
      setLikeCount((c) => c + (next ? 1 : -1));
      track("wishlist", { productId, categoryId: categoryId ?? undefined, brand });
      return next;
    });
  }

  async function handleShare() {
    const url = typeof window !== "undefined" ? window.location.href : "";
    if (navigator.share) {
      try {
        await navigator.share({ url, title: "Check this out on Teleplus Store" });
      } catch {
        // cancelled
      }
    } else {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
    track("click", { productId, categoryId: categoryId ?? undefined, brand });
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        onClick={toggleLike}
        className={`flex items-center gap-1.5 rounded-full border px-3.5 py-2 text-sm font-medium transition ${
          liked ? "border-red-200 bg-red-50 text-red-500" : "border-slate-200 text-slate-600 hover:border-slate-300"
        }`}
      >
        <Heart className={`h-4 w-4 ${liked ? "fill-red-500" : ""}`} /> {likeCount.toLocaleString()}
      </button>
      <button
        onClick={handleShare}
        className="flex items-center gap-1.5 rounded-full border border-slate-200 px-3.5 py-2 text-sm font-medium text-slate-600 transition hover:border-slate-300"
      >
        <Share2 className="h-4 w-4" /> {copied ? "Link copied!" : "Share"}
      </button>
      <span className="flex items-center gap-1.5 rounded-full bg-emerald-50 px-3.5 py-2 text-sm font-medium text-emerald-600">
        <Eye className="h-4 w-4" /> {viewers} viewing now
      </span>
      <span className="flex items-center gap-1.5 rounded-full bg-slate-100 px-3.5 py-2 text-sm font-medium text-slate-600">
        <MessageCircle className="h-4 w-4" /> {reviewCount} reviews
      </span>
    </div>
  );
}
