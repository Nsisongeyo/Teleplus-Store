"use client";

import { useState } from "react";
import { Star, BadgeCheck } from "lucide-react";
import StarRating from "@/components/star-rating";
import { timeAgo } from "@/lib/format";

type Review = {
  id: number;
  authorName: string;
  rating: number;
  title: string | null;
  body: string | null;
  verified: boolean;
  helpfulCount: number;
  createdAt: string;
};

export default function ReviewsSection({
  productId,
  initialReviews,
  rating,
  reviewCount,
}: {
  productId: number;
  initialReviews: Review[];
  rating: number;
  reviewCount: number;
}) {
  const [reviews, setReviews] = useState(initialReviews);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ authorName: "", rating: 5, title: "", body: "" });

  const breakdown = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: reviews.filter((r) => r.rating === star).length,
  }));
  const maxCount = Math.max(1, ...breakdown.map((b) => b.count));

  async function submitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!form.authorName.trim()) return;
    setSubmitting(true);
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId, ...form }),
    });
    const data = await res.json();
    if (data.review) {
      setReviews((prev) => [data.review, ...prev]);
      setForm({ authorName: "", rating: 5, title: "", body: "" });
      setShowForm(false);
    }
    setSubmitting(false);
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-8 sm:flex-row sm:items-start">
        <div className="flex flex-col items-center gap-2 rounded-3xl bg-slate-50 px-8 py-6 sm:items-start">
          <p className="font-display text-5xl font-bold text-slate-900">{rating.toFixed(1)}</p>
          <StarRating rating={rating} size={18} />
          <p className="text-sm text-slate-500">{reviewCount} reviews</p>
        </div>
        <div className="flex flex-1 flex-col gap-2">
          {breakdown.map((b) => (
            <div key={b.star} className="flex items-center gap-3">
              <span className="flex w-10 items-center gap-1 text-xs text-slate-500">
                {b.star} <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
              </span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100">
                <div
                  className="h-full rounded-full bg-amber-400 transition-all"
                  style={{ width: `${(b.count / maxCount) * 100}%` }}
                />
              </div>
              <span className="w-6 text-right text-xs text-slate-400">{b.count}</span>
            </div>
          ))}
          <button
            onClick={() => setShowForm((v) => !v)}
            className="mt-3 w-fit rounded-full bg-[#1881a2] px-5 py-2.5 text-xs font-semibold text-white transition hover:bg-[#106680]"
          >
            {showForm ? "Cancel" : "Write a Review"}
          </button>
        </div>
      </div>

      {showForm && (
        <form onSubmit={submitReview} className="flex flex-col gap-3 rounded-3xl border border-slate-200 p-5 animate-fade-in-up">
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((s) => (
              <button type="button" key={s} onClick={() => setForm((f) => ({ ...f, rating: s }))}>
                <Star
                  className={`h-6 w-6 ${s <= form.rating ? "fill-amber-400 text-amber-400" : "text-slate-300"}`}
                />
              </button>
            ))}
          </div>
          <input
            required
            value={form.authorName}
            onChange={(e) => setForm((f) => ({ ...f, authorName: e.target.value }))}
            placeholder="Your name"
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
          <input
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            placeholder="Review title (optional)"
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
          <textarea
            value={form.body}
            onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))}
            placeholder="Share your experience with this product..."
            rows={3}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-[#1881a2]"
          />
          <button
            disabled={submitting}
            className="w-fit rounded-full bg-slate-900 px-5 py-2.5 text-xs font-semibold text-white transition hover:bg-slate-800 disabled:opacity-50"
          >
            {submitting ? "Submitting..." : "Submit Review"}
          </button>
        </form>
      )}

      <div className="flex flex-col divide-y divide-slate-100">
        {reviews.map((r) => (
          <div key={r.id} className="flex flex-col gap-2 py-5">
            <div className="flex items-center gap-3">
              <div className="grid h-9 w-9 place-items-center rounded-full bg-[#1881a2]/10 font-display text-xs font-bold text-[#1881a2]">
                {r.authorName.charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-semibold text-slate-800">{r.authorName}</p>
                  {r.verified && (
                    <span className="flex items-center gap-0.5 text-[11px] font-medium text-emerald-600">
                      <BadgeCheck className="h-3.5 w-3.5" /> Verified
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400">{timeAgo(r.createdAt)}</p>
              </div>
            </div>
            <StarRating rating={r.rating} size={13} />
            {r.title && <p className="text-sm font-semibold text-slate-800">{r.title}</p>}
            {r.body && <p className="text-sm leading-relaxed text-slate-600">{r.body}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
