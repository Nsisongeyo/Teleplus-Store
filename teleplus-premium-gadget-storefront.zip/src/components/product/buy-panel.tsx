"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Minus, Plus, ShoppingBag, MessageCircle, ShieldCheck, Truck, RotateCcw } from "lucide-react";
import { useCartStore } from "@/store/cart";
import { formatNaira } from "@/lib/format";
import { buildWhatsappOrderLink } from "@/lib/whatsapp";
import { track } from "@/lib/visitor";

export default function BuyPanel({
  productId,
  slug,
  name,
  image,
  price,
  compareAtPrice,
  stock,
  vendorId,
  vendorName,
  categoryId,
  brand,
}: {
  productId: number;
  slug: string;
  name: string;
  image: string;
  price: number;
  compareAtPrice: number | null;
  stock: number;
  vendorId: number;
  vendorName: string;
  categoryId: number | null;
  brand: string;
}) {
  const [qty, setQty] = useState(1);
  const [origin, setOrigin] = useState("");
  const addItem = useCartStore((s) => s.addItem);
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== "undefined") setOrigin(window.location.origin);
  }, []);

  const inStock = stock > 0;
  const discount = compareAtPrice ? Math.round(((compareAtPrice - price) / compareAtPrice) * 100) : 0;
  const whatsappLink = buildWhatsappOrderLink({
    productName: name,
    price,
    url: `${origin}/product/${slug}`,
  });

  function handleAddToCart() {
    addItem(
      { productId, slug, name, image, price, vendorId, vendorName, stock },
      qty,
    );
    track("add_to_cart", { productId, categoryId: categoryId ?? undefined, brand });
  }

  function handleBuyNow() {
    handleAddToCart();
    router.push("/checkout");
  }

  function handleWhatsapp() {
    track("whatsapp", { productId, categoryId: categoryId ?? undefined, brand });
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-baseline gap-3">
        <span className="font-display text-3xl font-bold text-slate-900">{formatNaira(price)}</span>
        {compareAtPrice && compareAtPrice > price && (
          <>
            <span className="text-base text-slate-400 line-through">{formatNaira(compareAtPrice)}</span>
            <span className="rounded-full bg-red-50 px-2.5 py-1 text-xs font-bold text-red-500">Save {discount}%</span>
          </>
        )}
      </div>

      <p className={`text-sm font-medium ${inStock ? "text-emerald-600" : "text-red-500"}`}>
        {inStock ? `✓ In stock — ${stock} available` : "Out of stock"}
      </p>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-3 rounded-full border border-slate-200 px-2 py-1.5">
          <button
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            className="grid h-8 w-8 place-items-center rounded-full text-slate-600 hover:bg-slate-100"
          >
            <Minus className="h-4 w-4" />
          </button>
          <span className="w-5 text-center text-sm font-semibold">{qty}</span>
          <button
            onClick={() => setQty((q) => Math.min(stock || 99, q + 1))}
            className="grid h-8 w-8 place-items-center rounded-full text-slate-600 hover:bg-slate-100"
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <button
          disabled={!inStock}
          onClick={handleBuyNow}
          className="flex-1 rounded-full bg-slate-900 py-3.5 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Buy Now
        </button>
        <button
          disabled={!inStock}
          onClick={handleAddToCart}
          className="flex flex-1 items-center justify-center gap-2 rounded-full border-2 border-[#1881a2] py-3.5 text-sm font-semibold text-[#1881a2] transition hover:bg-[#1881a2]/5 disabled:cursor-not-allowed disabled:opacity-40"
        >
          <ShoppingBag className="h-4 w-4" /> Add to Cart
        </button>
      </div>

      <a
        href={whatsappLink}
        target="_blank"
        rel="noreferrer"
        onClick={handleWhatsapp}
        className="flex items-center justify-center gap-2 rounded-full bg-[#25D366] py-3.5 text-sm font-semibold text-white shadow-lg shadow-[#25D366]/25 transition hover:brightness-95"
      >
        <MessageCircle className="h-4 w-4" /> Buy via WhatsApp
      </a>
      <p className="-mt-2 text-center text-xs text-slate-400">
        Sends this product&apos;s photo &amp; details straight to our sales team for instant confirmation.
      </p>

      <div className="grid grid-cols-3 gap-3 border-t border-slate-100 pt-5 text-center">
        <div className="flex flex-col items-center gap-1.5">
          <Truck className="h-5 w-5 text-[#1881a2]" />
          <p className="text-[11px] text-slate-500">Fast Delivery</p>
        </div>
        <div className="flex flex-col items-center gap-1.5">
          <ShieldCheck className="h-5 w-5 text-[#1881a2]" />
          <p className="text-[11px] text-slate-500">Verified Product</p>
        </div>
        <div className="flex flex-col items-center gap-1.5">
          <RotateCcw className="h-5 w-5 text-[#1881a2]" />
          <p className="text-[11px] text-slate-500">7-Day Returns</p>
        </div>
      </div>
    </div>
  );
}
