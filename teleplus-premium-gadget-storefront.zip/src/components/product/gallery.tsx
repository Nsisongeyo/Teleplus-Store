"use client";

import { useState } from "react";
import Image from "next/image";

export default function Gallery({ images, name }: { images: string[]; name: string }) {
  const [active, setActive] = useState(0);
  const list = images.length ? images : ["/images/hero-devices.jpg"];

  return (
    <div className="flex flex-col gap-4">
      <div className="relative aspect-square w-full overflow-hidden rounded-3xl bg-slate-50 sm:rounded-[2rem]">
        <Image
          key={active}
          src={list[active]}
          alt={`${name} — image ${active + 1}`}
          fill
          priority
          sizes="(max-width: 1024px) 100vw, 560px"
          className="animate-fade-in-up object-cover"
        />
      </div>
      {list.length > 1 && (
        <div className="flex gap-3 overflow-x-auto no-scrollbar">
          {list.map((img, i) => (
            <button
              key={img + i}
              onClick={() => setActive(i)}
              className={`relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl border-2 transition ${
                active === i ? "border-[#1881a2]" : "border-transparent opacity-70 hover:opacity-100"
              }`}
            >
              <Image src={img} alt={`${name} thumbnail ${i + 1}`} fill sizes="80px" className="object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
