import { Star } from "lucide-react";

export default function StarRating({
  rating,
  size = 14,
  showValue = false,
  count,
}: {
  rating: number;
  size?: number;
  showValue?: boolean;
  count?: number;
}) {
  const rounded = Math.round(rating * 2) / 2;
  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center">
        {Array.from({ length: 5 }).map((_, i) => {
          const filled = i + 1 <= rounded;
          const half = !filled && i + 0.5 === rounded;
          return (
            <span key={i} className="relative inline-block" style={{ width: size, height: size }}>
              <Star
                width={size}
                height={size}
                className="absolute inset-0 text-amber-400"
                fill={filled ? "currentColor" : "none"}
                strokeWidth={1.5}
              />
              {half && (
                <span className="absolute inset-0 overflow-hidden" style={{ width: size / 2 }}>
                  <Star width={size} height={size} className="text-amber-400" fill="currentColor" strokeWidth={1.5} />
                </span>
              )}
            </span>
          );
        })}
      </div>
      {showValue && <span className="text-xs font-medium text-slate-500">{rating.toFixed(1)}</span>}
      {typeof count === "number" && <span className="text-xs text-slate-400">({count})</span>}
    </div>
  );
}
