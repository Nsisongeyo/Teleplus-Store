export function buildWhatsappOrderLink(params: {
  productName: string;
  price: number;
  url: string;
  phone?: string;
}) {
  const phone = params.phone || process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "2348012345678";
  const message =
    `Hi Teleplus Store 👋, is this still available? I want to buy it:\n\n` +
    `🛍️ ${params.productName}\n` +
    `💰 ₦${params.price.toLocaleString("en-NG")}\n` +
    `🔗 ${params.url}`;
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}
