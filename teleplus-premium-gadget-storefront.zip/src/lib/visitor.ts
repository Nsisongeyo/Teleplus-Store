"use client";

const KEY = "teleplus-visitor-id";

export function getVisitorId(): string {
  if (typeof window === "undefined") return "server";
  let id = localStorage.getItem(KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(KEY, id);
  }
  return id;
}

export function track(action: string, opts: { productId?: number; categoryId?: number; brand?: string } = {}) {
  try {
    const visitorId = getVisitorId();
    navigator.sendBeacon?.(
      "/api/track",
      new Blob([JSON.stringify({ visitorId, action, ...opts })], { type: "application/json" }),
    ) ||
      fetch("/api/track", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ visitorId, action, ...opts }),
        keepalive: true,
      });
  } catch {
    // ignore tracking errors
  }
}
