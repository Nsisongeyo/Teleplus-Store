import jwt from "jsonwebtoken";
import { cookies } from "next/headers";

const SECRET = process.env.AUTH_SECRET || "dev-secret";

export type AdminTokenPayload = {
  role: "admin";
  id: number;
  email: string;
  name: string;
};

export type VendorTokenPayload = {
  role: "vendor";
  id: number;
  email: string;
  name: string;
  status: string;
};

export type SessionPayload = AdminTokenPayload | VendorTokenPayload;

export function signToken(payload: SessionPayload) {
  return jwt.sign(payload, SECRET, { expiresIn: "30d" });
}

export function verifyToken<T = SessionPayload>(token: string): T | null {
  try {
    return jwt.verify(token, SECRET) as T;
  } catch {
    return null;
  }
}

export const ADMIN_COOKIE = "teleplus_admin_session";
export const VENDOR_COOKIE = "teleplus_vendor_session";

export async function getAdminSession(): Promise<AdminTokenPayload | null> {
  const store = await cookies();
  const token = store.get(ADMIN_COOKIE)?.value;
  if (!token) return null;
  const payload = verifyToken<AdminTokenPayload>(token);
  if (!payload || payload.role !== "admin") return null;
  return payload;
}

export async function getVendorSession(): Promise<VendorTokenPayload | null> {
  const store = await cookies();
  const token = store.get(VENDOR_COOKIE)?.value;
  if (!token) return null;
  const payload = verifyToken<VendorTokenPayload>(token);
  if (!payload || payload.role !== "vendor") return null;
  return payload;
}
