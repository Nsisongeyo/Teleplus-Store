import "dotenv/config";
import bcrypt from "bcryptjs";
import { db } from "./index";
import { categories, vendors, adminUsers, products, reviews } from "./schema";
import { slugify } from "../lib/format";

const IMG = {
  laptopSlate: "/images/products/laptop-slate.jpg",
  laptopPro: "/images/products/laptop-pro.jpg",
  laptopGaming: "/images/products/laptop-gaming.jpg",
  phoneFlagship: "/images/products/phone-flagship.jpg",
  phoneFlagshipBack: "/images/products/phone-flagship-back.jpg",
  phoneBudget: "/images/products/phone-budget.jpg",
  earbuds: "/images/products/earbuds.jpg",
  smartwatch: "/images/products/smartwatch.jpg",
  accessories: "/images/products/accessories-flatlay.jpg",
  hero: "/images/hero-devices.jpg",
  laptopLifestyle:
    "https://images.pexels.com/photos/29283981/pexels-photo-29283981.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=900",
  phoneLifestyle:
    "https://images.pexels.com/photos/20321375/pexels-photo-20321375.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=900",
  earbudsLifestyleMan:
    "https://images.pexels.com/photos/3394657/pexels-photo-3394657.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=900",
  earbudsLifestyleWoman:
    "https://images.pexels.com/photos/3756912/pexels-photo-3756912.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=900",
  earbudsCase:
    "https://images.pexels.com/photos/3394651/pexels-photo-3394651.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=900",
  headphonesWhite:
    "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=900",
};

const reviewPool = {
  5: [
    { title: "Absolutely worth it!", body: "Exceeded my expectations. Build quality feels premium and delivery was fast. Ordered via WhatsApp and the process was smooth." },
    { title: "Best purchase this year", body: "Performance is buttery smooth, battery lasts all day. Teleplus Store never disappoints." },
    { title: "Exactly as described", body: "Packaging was pristine, product is 100% authentic. Highly recommend this store to anyone in the market." },
    { title: "Five stars, no doubt", body: "Customer support on WhatsApp responded within minutes. The device itself is stunning in person." },
  ],
  4: [
    { title: "Great value for money", body: "Does everything I need, just wish the box included a few more accessories. Still very happy." },
    { title: "Solid device", body: "Very good performance for the price. Shipping took a couple of days longer than expected." },
    { title: "Pretty impressed", body: "Camera and display quality punch above the price point. Minor heating under heavy load." },
  ],
  3: [
    { title: "Decent, does the job", body: "It's okay for everyday tasks but nothing extraordinary. Battery could be better." },
  ],
};

const reviewerNames = [
  "Chidinma A.", "Emeka O.", "Tolu B.", "Fatima Y.", "David K.", "Ngozi E.",
  "Ibrahim S.", "Blessing U.", "Kunle A.", "Aisha M.", "Uche N.", "Segun T.",
  "Grace I.", "Chuka O.", "Zainab L.", "Peter A.", "Amaka C.", "Femi R.",
];

function genReviews(seedBase: number, count: number) {
  const out: { authorName: string; rating: number; title: string; body: string; verified: boolean; helpfulCount: number }[] = [];
  for (let i = 0; i < count; i++) {
    const roll = (seedBase + i * 13) % 10;
    const rating = roll < 6 ? 5 : roll < 9 ? 4 : 3;
    const pool = reviewPool[rating as 3 | 4 | 5];
    const pick = pool[(seedBase + i) % pool.length];
    const name = reviewerNames[(seedBase + i * 7) % reviewerNames.length];
    out.push({
      authorName: name,
      rating,
      title: pick.title,
      body: pick.body,
      verified: (seedBase + i) % 5 !== 0,
      helpfulCount: (seedBase * 3 + i * 5) % 40,
    });
  }
  return out;
}

async function main() {
  console.log("Seeding database...");

  await db.delete(reviews);
  await db.delete(products);
  await db.delete(adminUsers);
  await db.delete(vendors);
  await db.delete(categories);

  const [laptopsCat, phonesCat, accessoriesCat] = await db
    .insert(categories)
    .values([
      { name: "Laptops", slug: "laptops", icon: "laptop", sortOrder: 1 },
      { name: "Phones", slug: "phones", icon: "smartphone", sortOrder: 2 },
      { name: "Accessories", slug: "accessories", icon: "headphones", sortOrder: 3 },
    ])
    .returning();

  const adminPasswordHash = await bcrypt.hash("Teleplus@2026", 10);
  await db.insert(adminUsers).values({
    email: "admin@teleplus.store",
    passwordHash: adminPasswordHash,
    name: "Teleplus Admin",
  });

  const vendorPasswordHash = await bcrypt.hash("Vendor@2026", 10);
  const [teleplus, nexatech, gadgethub, quickcell] = await db
    .insert(vendors)
    .values([
      {
        name: "Teleplus Store",
        slug: "teleplus-store",
        email: "vendor@teleplus.store",
        passwordHash: vendorPasswordHash,
        phone: "2348012345678",
        description: "Official flagship store for Teleplus — laptops, phones & accessories for every gadget lover.",
        logoEmoji: "🟦",
        status: "approved",
        isOfficial: true,
      },
      {
        name: "NexaTech Gadgets",
        slug: "nexatech-gadgets",
        email: "hello@nexatech.example",
        passwordHash: vendorPasswordHash,
        phone: "2348023456789",
        description: "Trusted marketplace seller specializing in flagship phones and premium laptops.",
        logoEmoji: "🟣",
        status: "approved",
        isOfficial: false,
      },
      {
        name: "GadgetHub NG",
        slug: "gadgethub-ng",
        email: "sales@gadgethubng.example",
        passwordHash: vendorPasswordHash,
        phone: "2348034567890",
        description: "Your one-stop shop for affordable, quality-checked gadget accessories.",
        logoEmoji: "🟧",
        status: "approved",
        isOfficial: false,
      },
      {
        name: "QuickCell Accessories",
        slug: "quickcell-accessories",
        email: "info@quickcell.example",
        passwordHash: vendorPasswordHash,
        phone: "2348045678901",
        description: "New marketplace vendor awaiting approval — accessories & phone cases.",
        logoEmoji: "🟨",
        status: "pending",
        isOfficial: false,
      },
    ])
    .returning();

  type Seed = {
    name: string;
    brand: string;
    categoryId: number;
    vendorId: number;
    price: number;
    compareAtPrice?: number;
    stock: number;
    images: string[];
    specs: Record<string, string>;
    tags: string[];
    shortDescription: string;
    description: string;
    featured?: boolean;
    status?: string;
    sold: number;
  };

  const laptops: Seed[] = [
    {
      name: "AirBook 13 M-Series",
      brand: "AeroTech",
      categoryId: laptopsCat.id,
      vendorId: teleplus.id,
      price: 1250000,
      compareAtPrice: 1450000,
      stock: 14,
      images: [IMG.laptopSlate, IMG.laptopLifestyle, IMG.laptopPro],
      specs: { Processor: "8-core Neural Chip", RAM: "16GB Unified Memory", Storage: "512GB SSD", Display: "13.6\" Liquid Retina", Battery: "Up to 18 hours", Weight: "1.24kg" },
      tags: ["ultrabook", "lightweight", "bestseller"],
      shortDescription: "Impossibly thin, incredibly powerful — the everyday ultrabook for creators on the move.",
      description: "The AirBook 13 M-Series redefines what a thin-and-light laptop can do. With a stunning Liquid Retina display, all-day battery life, and a silent fanless design, it's built for students, creators, and professionals who need power without the bulk. Finished in a premium aluminium unibody with a Space Silver coat.",
      featured: true,
      sold: 342,
    },
    {
      name: "ProBook 16 Elite",
      brand: "AeroTech",
      categoryId: laptopsCat.id,
      vendorId: teleplus.id,
      price: 2450000,
      compareAtPrice: 2700000,
      stock: 8,
      images: [IMG.laptopPro, IMG.laptopLifestyle],
      specs: { Processor: "12-core Pro Chip", RAM: "32GB Unified Memory", Storage: "1TB SSD", Display: "16.2\" Liquid Retina XDR", Battery: "Up to 22 hours", Ports: "3x Thunderbolt 4, HDMI, SD" },
      tags: ["pro", "creator", "premium"],
      shortDescription: "Studio-grade performance for video editing, 3D rendering and pro workflows.",
      description: "Built for professionals who push their machines to the limit. The ProBook 16 Elite pairs a stunning XDR display with a 12-core chip that chews through 8K video timelines, giant Figma boards and compiling code without breaking a sweat.",
      featured: true,
      sold: 128,
    },
    {
      name: "UltraSlim 14 Ryzen Edition",
      brand: "Novacore",
      categoryId: laptopsCat.id,
      vendorId: nexatech.id,
      price: 890000,
      compareAtPrice: 990000,
      stock: 20,
      images: [IMG.laptopSlate, IMG.laptopPro],
      specs: { Processor: "AMD Ryzen 7 8845HS", RAM: "16GB DDR5", Storage: "512GB NVMe SSD", Display: "14\" 2.8K OLED 90Hz", Battery: "Up to 14 hours", Weight: "1.3kg" },
      tags: ["oled", "windows", "value"],
      shortDescription: "A vivid OLED windows ultrabook that punches well above its price.",
      description: "The UltraSlim 14 delivers a jaw-dropping 2.8K OLED panel, a fast Ryzen 8000-series processor and a metal chassis that feels far pricier than it is. Perfect for hybrid work, binge-watching and light creative work on the go.",
      sold: 96,
    },
    {
      name: "GameForce X15",
      brand: "Novacore",
      categoryId: laptopsCat.id,
      vendorId: nexatech.id,
      price: 1980000,
      compareAtPrice: 2200000,
      stock: 6,
      images: [IMG.laptopGaming, IMG.laptopPro],
      specs: { Processor: "Intel Core i9-14900HX", GPU: "RTX 4070 8GB", RAM: "32GB DDR5", Storage: "1TB NVMe SSD", Display: "15.6\" QHD 240Hz", Cooling: "Vapor Chamber + RGB" },
      tags: ["gaming", "rgb", "high-performance"],
      shortDescription: "Tournament-ready power with a blazing 240Hz display and RGB flair.",
      description: "Dominate every match with the GameForce X15 — an RTX 4070 GPU, blistering 240Hz QHD panel and per-key RGB keyboard. Advanced vapor-chamber cooling keeps clocks high even during marathon sessions.",
      featured: true,
      sold: 74,
    },
    {
      name: "StudioBook Pro 15 Creator",
      brand: "Visionary",
      categoryId: laptopsCat.id,
      vendorId: teleplus.id,
      price: 1650000,
      stock: 11,
      images: [IMG.laptopPro, IMG.laptopSlate],
      specs: { Processor: "Intel Core Ultra 9", GPU: "RTX 4060 8GB", RAM: "32GB DDR5", Storage: "1TB SSD", Display: "15.6\" 4K Touch OLED", ColorAccuracy: "100% DCI-P3" },
      tags: ["creator", "touchscreen", "oled"],
      shortDescription: "Color-accurate 4K OLED touch display built for designers and editors.",
      description: "From photo retouching to 4K video grading, the StudioBook Pro 15 delivers factory-calibrated color accuracy on a stunning OLED touch panel, backed by serious rendering horsepower.",
      sold: 51,
    },
    {
      name: "EliteBook Business 14",
      brand: "AeroTech",
      categoryId: laptopsCat.id,
      vendorId: teleplus.id,
      price: 980000,
      stock: 17,
      images: [IMG.laptopSlate, IMG.laptopPro],
      specs: { Processor: "Intel Core i7-1355U", RAM: "16GB LPDDR5", Storage: "512GB SSD", Display: "14\" FHD+ Anti-glare", Security: "Fingerprint + TPM 2.0", Battery: "Up to 16 hours" },
      tags: ["business", "office", "lightweight"],
      shortDescription: "Enterprise-grade security and reliability for the modern workplace.",
      description: "Designed for the boardroom and beyond, the EliteBook Business 14 combines a durable magnesium-alloy chassis, military-grade durability testing and enterprise security features like fingerprint login and TPM 2.0.",
      sold: 143,
    },
    {
      name: "ChromeLite 11 EDU",
      brand: "Novacore",
      categoryId: laptopsCat.id,
      vendorId: gadgethub.id,
      price: 320000,
      compareAtPrice: 380000,
      stock: 30,
      images: [IMG.laptopSlate],
      specs: { Processor: "Octa-core Mobile Chip", RAM: "8GB", Storage: "128GB eMMC", Display: "11.6\" HD", Battery: "Up to 12 hours", Weight: "1.1kg" },
      tags: ["budget", "student", "lightweight"],
      shortDescription: "Affordable, durable and fast — the perfect companion for students.",
      description: "The ChromeLite 11 is built for classrooms and dorm rooms. Lightweight, quick to boot and easy on the budget, it handles browsing, docs and streaming with ease.",
      sold: 210,
    },
    {
      name: "Workstation 17 Creator Max",
      brand: "Visionary",
      categoryId: laptopsCat.id,
      vendorId: nexatech.id,
      price: 3200000,
      stock: 4,
      images: [IMG.laptopPro, IMG.laptopGaming],
      specs: { Processor: "Intel Core i9-14900HX", GPU: "RTX 4090 16GB", RAM: "64GB DDR5", Storage: "2TB SSD RAID", Display: "17\" 4K Mini-LED 120Hz" },
      tags: ["workstation", "premium", "creator"],
      shortDescription: "The ultimate desktop-replacement workstation for 3D artists and studios.",
      description: "No compromises. The Workstation 17 Creator Max houses desktop-class silicon in a portable chassis — ideal for 3D rendering, AI workloads and multi-cam video production.",
      sold: 22,
    },
  ];

  const phones: Seed[] = [
    {
      name: "Nova 15 Pro Max",
      brand: "Novaris",
      categoryId: phonesCat.id,
      vendorId: teleplus.id,
      price: 1750000,
      compareAtPrice: 1950000,
      stock: 25,
      images: [IMG.phoneFlagship, IMG.phoneFlagshipBack, IMG.phoneLifestyle],
      specs: { Display: "6.9\" LTPO OLED 120Hz", Chip: "A18 Bionic Pro", Storage: "512GB", Camera: "50MP Triple + Periscope Zoom", Battery: "5000mAh, 45W Fast Charge", Build: "Titanium Frame" },
      tags: ["flagship", "bestseller", "5g"],
      shortDescription: "Titanium. Periscope zoom. The most powerful Nova ever made.",
      description: "Nova 15 Pro Max sets a new benchmark with a titanium frame, a periscope zoom camera system that reaches 10x optical zoom, and the fastest chip in a smartphone yet. A true flagship experience.",
      featured: true,
      sold: 512,
    },
    {
      name: "Nova 15",
      brand: "Novaris",
      categoryId: phonesCat.id,
      vendorId: teleplus.id,
      price: 1150000,
      compareAtPrice: 1290000,
      stock: 30,
      images: [IMG.phoneFlagship, IMG.phoneFlagshipBack],
      specs: { Display: "6.4\" OLED 120Hz", Chip: "A18 Bionic", Storage: "256GB", Camera: "48MP Dual", Battery: "4200mAh, 30W Fast Charge" },
      tags: ["flagship", "5g", "compact"],
      shortDescription: "All the flagship essentials in a perfectly pocketable size.",
      description: "Nova 15 delivers flagship performance, a gorgeous OLED display and a refined dual-camera system, wrapped in a compact aerospace-grade aluminium frame.",
      featured: true,
      sold: 389,
    },
    {
      name: "Fusion X Ultra",
      brand: "Solstice",
      categoryId: phonesCat.id,
      vendorId: nexatech.id,
      price: 1620000,
      compareAtPrice: 1800000,
      stock: 18,
      images: [IMG.phoneFlagshipBack, IMG.phoneFlagship, IMG.phoneLifestyle],
      specs: { Display: "6.8\" Dynamic AMOLED 2X", Chip: "Snapdragon Elite Gen 4", Storage: "512GB", Camera: "200MP Quad + S-Pen", Battery: "5500mAh, 65W Fast Charge" },
      tags: ["flagship", "s-pen", "android"],
      shortDescription: "A 200MP powerhouse with S-Pen precision for work and play.",
      description: "Fusion X Ultra pushes Android to its limits with a 200MP main sensor, built-in stylus support, and a massive 5500mAh battery that easily lasts two days of heavy use.",
      featured: true,
      sold: 271,
    },
    {
      name: "Fusion X",
      brand: "Solstice",
      categoryId: phonesCat.id,
      vendorId: nexatech.id,
      price: 980000,
      stock: 22,
      images: [IMG.phoneFlagship, IMG.phoneFlagshipBack],
      specs: { Display: "6.5\" AMOLED 120Hz", Chip: "Snapdragon 8 Gen 3", Storage: "256GB", Camera: "50MP Triple", Battery: "4900mAh, 45W Fast Charge" },
      tags: ["android", "5g", "value"],
      shortDescription: "Flagship-grade cameras and performance at a smarter price.",
      description: "Fusion X brings the core flagship experience — a fluid AMOLED display, capable triple-camera system and all-day battery — without the flagship price tag.",
      sold: 198,
    },
    {
      name: "Pulse Lite 5G",
      brand: "Solstice",
      categoryId: phonesCat.id,
      vendorId: gadgethub.id,
      price: 385000,
      compareAtPrice: 430000,
      stock: 40,
      images: [IMG.phoneBudget, IMG.phoneLifestyle],
      specs: { Display: "6.6\" IPS LCD 90Hz", Chip: "Dimensity 6100+", Storage: "128GB", Camera: "50MP Dual", Battery: "5000mAh, 18W Charge" },
      tags: ["budget", "5g", "student"],
      shortDescription: "Reliable 5G speed and all-day battery for everyday life.",
      description: "Pulse Lite 5G is built for real life — a big battery, a smooth 90Hz display and 5G connectivity, all at a price that makes sense.",
      sold: 456,
    },
    {
      name: "Pulse Max",
      brand: "Solstice",
      categoryId: phonesCat.id,
      vendorId: gadgethub.id,
      price: 560000,
      stock: 26,
      images: [IMG.phoneBudget, IMG.phoneFlagship],
      specs: { Display: "6.7\" AMOLED 120Hz", Chip: "Dimensity 8300", Storage: "256GB", Camera: "64MP OIS Triple", Battery: "5200mAh, 67W Fast Charge" },
      tags: ["mid-range", "5g", "camera"],
      shortDescription: "AMOLED brilliance and OIS camera stability, mid-range price.",
      description: "Pulse Max punches well above its category with a vivid AMOLED panel, optically stabilised triple cameras and blazing 67W charging that tops up the battery in under 40 minutes.",
      sold: 167,
    },
    {
      name: "EdgeView Fold",
      brand: "Novaris",
      categoryId: phonesCat.id,
      vendorId: teleplus.id,
      price: 2650000,
      stock: 5,
      images: [IMG.phoneFlagship, IMG.phoneFlagshipBack],
      specs: { Display: "7.6\" Foldable AMOLED + 6.2\" Cover", Chip: "A18 Bionic Pro", Storage: "512GB", Camera: "50MP Triple", Battery: "4800mAh, 45W Charge" },
      tags: ["foldable", "flagship", "innovative"],
      shortDescription: "A pocketable phone that unfolds into a full tablet experience.",
      description: "EdgeView Fold seamlessly transitions from a compact phone to a tablet-sized canvas, with an near-invisible crease and multitasking features made for productivity on the move.",
      featured: true,
      sold: 34,
    },
    {
      name: "Aero 12 Mini",
      brand: "Novaris",
      categoryId: phonesCat.id,
      vendorId: nexatech.id,
      price: 720000,
      stock: 19,
      images: [IMG.phoneFlagship, IMG.phoneBudget],
      specs: { Display: "5.8\" OLED 60Hz", Chip: "A16 Bionic", Storage: "128GB", Camera: "12MP Dual", Battery: "3200mAh, 20W Charge" },
      tags: ["compact", "lightweight"],
      shortDescription: "Small in size, mighty in performance — for one-hand lovers.",
      description: "Aero 12 Mini proves great things come in small packages, with flagship-grade performance packed into a compact, one-hand-friendly frame.",
      sold: 88,
    },
  ];

  const accessories: Seed[] = [
    {
      name: "SoundPods Pro ANC",
      brand: "Auralite",
      categoryId: accessoriesCat.id,
      vendorId: teleplus.id,
      price: 145000,
      compareAtPrice: 175000,
      stock: 60,
      images: [IMG.earbuds, IMG.earbudsLifestyleMan, IMG.earbudsCase],
      specs: { Type: "In-ear True Wireless", ANC: "Adaptive Active Noise Cancelling", Battery: "8h + 32h case", Water: "IPX4", Chip: "H2 Audio Chip" },
      tags: ["audio", "anc", "bestseller"],
      shortDescription: "Immersive adaptive noise cancellation with spatial audio.",
      description: "SoundPods Pro ANC deliver studio-quality sound with adaptive noise cancellation that adjusts to your environment in real time. Featherlight, sweat resistant, and built for all-day wear.",
      featured: true,
      sold: 612,
    },
    {
      name: "SoundPods Air",
      brand: "Auralite",
      categoryId: accessoriesCat.id,
      vendorId: gadgethub.id,
      price: 62000,
      compareAtPrice: 78000,
      stock: 90,
      images: [IMG.earbuds, IMG.earbudsLifestyleWoman],
      specs: { Type: "In-ear True Wireless", Battery: "6h + 24h case", Water: "IPX4", Controls: "Touch Controls" },
      tags: ["audio", "value"],
      shortDescription: "Everyday earbuds with crisp sound and a featherlight fit.",
      description: "SoundPods Air bring reliable sound quality, touch controls and a compact charging case — an easy everyday upgrade from wired headphones.",
      sold: 745,
    },
    {
      name: "PulseWatch Ultra",
      brand: "Auralite",
      categoryId: accessoriesCat.id,
      vendorId: teleplus.id,
      price: 285000,
      compareAtPrice: 320000,
      stock: 24,
      images: [IMG.smartwatch],
      specs: { Display: "1.9\" AMOLED Always-On", Battery: "Up to 36 hours", Health: "ECG, SpO2, Heart Rate", Water: "10ATM Water Resistant", GPS: "Dual-frequency GPS" },
      tags: ["wearable", "fitness", "premium"],
      shortDescription: "Rugged titanium smartwatch built for athletes and explorers.",
      description: "PulseWatch Ultra tracks every heartbeat, dive and summit with precision sensors, a bright always-on display and a titanium case rated for extreme conditions.",
      featured: true,
      sold: 213,
    },
    {
      name: "PulseWatch SE",
      brand: "Auralite",
      categoryId: accessoriesCat.id,
      vendorId: gadgethub.id,
      price: 128000,
      stock: 38,
      images: [IMG.smartwatch],
      specs: { Display: "1.6\" AMOLED", Battery: "Up to 5 days", Health: "Heart Rate, SpO2, Sleep", Water: "5ATM" },
      tags: ["wearable", "fitness", "value"],
      shortDescription: "Essential health tracking with a week of battery life.",
      description: "PulseWatch SE covers all the fitness essentials — heart rate, sleep and SpO2 tracking — with battery life that easily lasts the work week.",
      sold: 301,
    },
    {
      name: "PowerCell 20K Fast Charge",
      brand: "VoltBox",
      categoryId: accessoriesCat.id,
      vendorId: gadgethub.id,
      price: 38000,
      stock: 120,
      images: [IMG.accessories],
      specs: { Capacity: "20,000mAh", Output: "65W PD Fast Charge", Ports: "2x USB-C, 1x USB-A", Display: "LED Battery Indicator" },
      tags: ["power", "travel", "bestseller"],
      shortDescription: "Charge a laptop and phone simultaneously, twice over.",
      description: "PowerCell 20K packs enough juice to fast-charge a laptop and two phones on a single charge, with pass-through charging and a durable travel-ready shell.",
      sold: 890,
    },
    {
      name: "FlashCharge 65W GaN Adapter",
      brand: "VoltBox",
      categoryId: accessoriesCat.id,
      vendorId: teleplus.id,
      price: 24500,
      stock: 150,
      images: [IMG.accessories],
      specs: { Output: "65W GaN Fast Charge", Ports: "2x USB-C, 1x USB-A", Compatibility: "Laptops, Phones, Tablets", Plug: "Foldable Prongs" },
      tags: ["charger", "gan", "travel"],
      shortDescription: "Pocket-sized charger that powers your whole gadget bag.",
      description: "FlashCharge's compact GaN design delivers desktop-charger speeds from a plug smaller than your palm — enough to fast-charge a laptop and two accessories at once.",
      sold: 623,
    },
    {
      name: "HubConnect 7-in-1 USB-C Hub",
      brand: "VoltBox",
      categoryId: accessoriesCat.id,
      vendorId: nexatech.id,
      price: 32000,
      stock: 70,
      images: [IMG.accessories],
      specs: { Ports: "HDMI 4K60, 2x USB-A 3.0, SD/microSD, USB-C PD 100W", Build: "Aluminium Unibody" },
      tags: ["laptop", "connectivity"],
      shortDescription: "Turn one port into seven — display, storage and power.",
      description: "HubConnect expands a single USB-C port into a full docking experience: 4K HDMI output, blazing data ports, card readers and 100W pass-through charging.",
      sold: 178,
    },
    {
      name: "ShieldCase Armor for Nova 15 Pro Max",
      brand: "GuardianGear",
      categoryId: accessoriesCat.id,
      vendorId: gadgethub.id,
      price: 15500,
      stock: 200,
      images: [IMG.phoneFlagshipBack],
      specs: { Material: "Military-grade TPU + Polycarbonate", Protection: "4m Drop Tested", Compatibility: "Nova 15 Pro Max" },
      tags: ["case", "protection"],
      shortDescription: "Drop-tested protection that doesn't hide your phone's design.",
      description: "ShieldCase Armor absorbs shock from up to 4 metre drops while keeping a slim profile and full access to all ports and buttons.",
      sold: 402,
    },
    {
      name: "ClearGuard Case for Fusion X Ultra",
      brand: "GuardianGear",
      categoryId: accessoriesCat.id,
      vendorId: gadgethub.id,
      price: 13500,
      stock: 180,
      images: [IMG.phoneFlagship],
      specs: { Material: "Anti-yellowing Clear TPU", Protection: "3m Drop Tested", Compatibility: "Fusion X Ultra" },
      tags: ["case", "protection"],
      shortDescription: "Crystal-clear protection that never turns yellow.",
      description: "ClearGuard's anti-yellowing formula keeps your case looking brand new for years, while raised bezels protect the screen and camera from scratches.",
      sold: 265,
    },
    {
      name: "BoomBox Mini Bluetooth Speaker",
      brand: "Auralite",
      categoryId: accessoriesCat.id,
      vendorId: nexatech.id,
      price: 58000,
      compareAtPrice: 69000,
      stock: 45,
      images: [IMG.accessories, IMG.headphonesWhite],
      specs: { Output: "20W Stereo Sound", Battery: "18 hours playback", Water: "IPX7 Waterproof", Connectivity: "Bluetooth 5.3" },
      tags: ["audio", "outdoor", "waterproof"],
      shortDescription: "Room-filling sound in a rugged, waterproof shell.",
      description: "BoomBox Mini delivers surprisingly big, punchy sound from a compact waterproof body built for pool days, hikes and everything in between.",
      sold: 334,
    },
    {
      name: "PrecisionClick Wireless Mouse",
      brand: "VoltBox",
      categoryId: accessoriesCat.id,
      vendorId: teleplus.id,
      price: 21000,
      stock: 95,
      images: [IMG.accessories],
      specs: { DPI: "Up to 4000 DPI", Connectivity: "Bluetooth + 2.4GHz Dongle", Battery: "Up to 3 months", Buttons: "6 Programmable" },
      tags: ["laptop", "productivity"],
      shortDescription: "Silent clicks, precise tracking, months of battery life.",
      description: "PrecisionClick brings ergonomic comfort and pinpoint tracking to any desk setup, with silent switches and months of battery life from two AA batteries.",
      sold: 289,
    },
    {
      name: "TypeMaster Mechanical Keyboard",
      brand: "VoltBox",
      categoryId: accessoriesCat.id,
      vendorId: nexatech.id,
      price: 68000,
      compareAtPrice: 79000,
      stock: 33,
      images: [IMG.accessories],
      specs: { Switches: "Hot-swappable Tactile Brown", Backlight: "Per-key RGB", Connectivity: "Bluetooth 5.1 + Wired", Battery: "4000mAh" },
      tags: ["keyboard", "rgb", "productivity"],
      shortDescription: "Satisfying tactile typing with vibrant per-key RGB.",
      description: "TypeMaster's hot-swappable switches let you customise your feel, while a sturdy aluminium frame and per-key RGB make it as beautiful as it is functional.",
      sold: 156,
    },
    {
      name: "TravelSleeve 14\" Laptop Sleeve",
      brand: "GuardianGear",
      categoryId: accessoriesCat.id,
      vendorId: quickcell.id,
      price: 17500,
      stock: 55,
      images: [IMG.accessories],
      specs: { Material: "Water-resistant Neoprene", Fit: "Up to 14\" Laptops", Extra: "Front Accessory Pocket" },
      tags: ["laptop", "travel"],
      shortDescription: "Slim, padded protection for laptops on the move.",
      description: "TravelSleeve wraps your laptop in water-resistant neoprene padding with a handy front pocket for chargers and cables.",
      status: "pending",
      sold: 12,
    },
  ];

  const allSeeds = [...laptops, ...phones, ...accessories];

  let ratingSeed = 3;
  for (const seed of allSeeds) {
    const generatedReviews = genReviews(ratingSeed, 3 + (ratingSeed % 4));
    const avgRating =
      generatedReviews.reduce((sum, r) => sum + r.rating, 0) / generatedReviews.length;

    const [inserted] = await db
      .insert(products)
      .values({
        vendorId: seed.vendorId,
        categoryId: seed.categoryId,
        name: seed.name,
        slug: slugify(seed.name),
        brand: seed.brand,
        shortDescription: seed.shortDescription,
        description: seed.description,
        specs: seed.specs,
        images: seed.images,
        price: seed.price.toString(),
        compareAtPrice: seed.compareAtPrice ? seed.compareAtPrice.toString() : null,
        stock: seed.stock,
        tags: seed.tags,
        status: seed.status || "live",
        rating: avgRating.toFixed(2),
        reviewCount: generatedReviews.length,
        soldCount: seed.sold,
        isFeatured: !!seed.featured,
      })
      .returning();

    await db.insert(reviews).values(
      generatedReviews.map((r) => ({
        productId: inserted.id,
        authorName: r.authorName,
        rating: r.rating,
        title: r.title,
        body: r.body,
        verified: r.verified,
        helpfulCount: r.helpfulCount,
      })),
    );

    ratingSeed += 7;
  }

  console.log(`Seeded ${allSeeds.length} products with reviews.`);
  console.log("Admin login: admin@teleplus.store / Teleplus@2026");
  console.log("Vendor login (any vendor email above) / Vendor@2026");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
