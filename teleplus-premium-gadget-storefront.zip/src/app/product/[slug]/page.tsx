import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { db } from "@/db";
import { products, categories, vendors, reviews as reviewsTable } from "@/db/schema";
import { and, desc, eq, ne } from "drizzle-orm";
import Gallery from "@/components/product/gallery";
import BuyPanel from "@/components/product/buy-panel";
import SocialBar from "@/components/product/social-bar";
import ReviewsSection from "@/components/product/reviews-section";
import ViewTracker from "@/components/product/view-tracker";
import ProductCard from "@/components/product-card";
import Link from "next/link";
import { ChevronRight, Store } from "lucide-react";

export const dynamic = "force-dynamic";

async function getProduct(slug: string) {
  const [row] = await db
    .select({
      product: products,
      categoryName: categories.name,
      categorySlug: categories.slug,
      vendorName: vendors.name,
      vendorSlug: vendors.slug,
      vendorId: vendors.id,
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .leftJoin(vendors, eq(products.vendorId, vendors.id))
    .where(eq(products.slug, slug))
    .limit(1);
  return row;
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const row = await getProduct(slug);
  if (!row) return { title: "Product not found — Teleplus Store" };
  const { product } = row;
  const image = product.images?.[0] || "/images/hero-devices.jpg";
  return {
    title: `${product.name} — Teleplus Store`,
    description: product.shortDescription || product.description || undefined,
    openGraph: {
      title: `${product.name} — ₦${Number(product.price).toLocaleString("en-NG")}`,
      description: product.shortDescription || "Available now at Teleplus Store",
      images: [{ url: image, width: 1200, height: 1200 }],
      type: "website",
    },
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const row = await getProduct(slug);
  if (!row) notFound();

  const { product, categoryName, categorySlug, vendorName, vendorSlug } = row;

  const productReviews = await db
    .select()
    .from(reviewsTable)
    .where(eq(reviewsTable.productId, product.id))
    .orderBy(desc(reviewsTable.createdAt));

  const related = await db
    .select({
      id: products.id,
      name: products.name,
      slug: products.slug,
      brand: products.brand,
      shortDescription: products.shortDescription,
      images: products.images,
      price: products.price,
      compareAtPrice: products.compareAtPrice,
      stock: products.stock,
      rating: products.rating,
      reviewCount: products.reviewCount,
      soldCount: products.soldCount,
      isFeatured: products.isFeatured,
      categoryId: products.categoryId,
      vendorId: products.vendorId,
    })
    .from(products)
    .where(and(eq(products.categoryId, product.categoryId ?? 0), ne(products.id, product.id), eq(products.status, "live")))
    .orderBy(desc(products.rating))
    .limit(4);

  const specs = (product.specs || {}) as Record<string, string>;

  return (
    <main className="mx-auto max-w-6xl px-4 pb-24 pt-8 sm:px-6 lg:px-8">
      <ViewTracker productId={product.id} categoryId={product.categoryId} brand={product.brand} />

      <div className="mb-6 flex items-center gap-1.5 text-xs text-slate-400">
        <Link href="/" className="hover:text-slate-600">
          Home
        </Link>
        <ChevronRight className="h-3 w-3" />
        {categorySlug && (
          <>
            <Link href={`/?category=${categorySlug}`} className="hover:text-slate-600">
              {categoryName}
            </Link>
            <ChevronRight className="h-3 w-3" />
          </>
        )}
        <span className="text-slate-600">{product.name}</span>
      </div>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
        <Gallery images={product.images || []} name={product.name} />

        <div className="flex flex-col gap-5">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#1881a2]">{product.brand}</p>
            <h1 className="mt-1 font-display text-2xl font-bold text-slate-900 sm:text-3xl">{product.name}</h1>
            {product.shortDescription && (
              <p className="mt-2 text-base text-slate-600">{product.shortDescription}</p>
            )}
          </div>

          <SocialBar
            productId={product.id}
            categoryId={product.categoryId}
            brand={product.brand}
            soldCount={product.soldCount}
            reviewCount={product.reviewCount}
          />

          {vendorName && (
            <Link
              href={`/vendors/${vendorSlug}`}
              className="flex w-fit items-center gap-2 rounded-full border border-slate-200 px-3.5 py-2 text-xs font-medium text-slate-600 transition hover:border-slate-300"
            >
              <Store className="h-3.5 w-3.5 text-[#1881a2]" /> Sold by <span className="font-semibold text-slate-800">{vendorName}</span>
            </Link>
          )}

          <hr className="border-slate-100" />

          <BuyPanel
            productId={product.id}
            slug={product.slug}
            name={product.name}
            image={product.images?.[0] || "/images/hero-devices.jpg"}
            price={Number(product.price)}
            compareAtPrice={product.compareAtPrice ? Number(product.compareAtPrice) : null}
            stock={product.stock}
            vendorId={product.vendorId}
            vendorName={vendorName || "Teleplus Store"}
            categoryId={product.categoryId}
            brand={product.brand}
          />
        </div>
      </div>

      <div className="mt-16 grid grid-cols-1 gap-10 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <h2 className="mb-4 font-display text-lg font-bold text-slate-900">About this product</h2>
          <p className="whitespace-pre-line leading-relaxed text-slate-600">{product.description}</p>

          {product.tags && product.tags.length > 0 && (
            <div className="mt-5 flex flex-wrap gap-2">
              {product.tags.map((tag) => (
                <span key={tag} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-500">
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>

        {Object.keys(specs).length > 0 && (
          <div>
            <h2 className="mb-4 font-display text-lg font-bold text-slate-900">Specifications</h2>
            <dl className="flex flex-col divide-y divide-slate-100 rounded-2xl border border-slate-100">
              {Object.entries(specs).map(([key, value]) => (
                <div key={key} className="flex justify-between gap-4 px-4 py-3 text-sm">
                  <dt className="text-slate-400">{key}</dt>
                  <dd className="text-right font-medium text-slate-700">{value}</dd>
                </div>
              ))}
            </dl>
          </div>
        )}
      </div>

      <div className="mt-16">
        <h2 className="mb-6 font-display text-lg font-bold text-slate-900">Ratings &amp; Reviews</h2>
        <ReviewsSection
          productId={product.id}
          initialReviews={productReviews.map((r) => ({ ...r, createdAt: r.createdAt.toString() }))}
          rating={Number(product.rating || 0)}
          reviewCount={product.reviewCount}
        />
      </div>

      {related.length > 0 && (
        <div className="mt-16">
          <h2 className="mb-6 font-display text-lg font-bold text-slate-900">You may also like</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </main>
  );
}
