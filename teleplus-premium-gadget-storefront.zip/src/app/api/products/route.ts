import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products, categories, vendors } from "@/db/schema";
import { and, asc, desc, eq, gte, lte, or, ilike, sql, ne } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const category = sp.get("category");
  const brand = sp.get("brand");
  const q = sp.get("q");
  const sort = sp.get("sort") || "relevance";
  const minPrice = sp.get("minPrice");
  const maxPrice = sp.get("maxPrice");
  const excludeId = sp.get("exclude");
  const featured = sp.get("featured");
  const page = parseInt(sp.get("page") || "0", 10);
  const limit = Math.min(parseInt(sp.get("limit") || "12", 10), 24);

  const conditions = [eq(products.status, "live")];

  if (category) {
    const [catRow] = await db.select().from(categories).where(eq(categories.slug, category)).limit(1);
    if (catRow) conditions.push(eq(products.categoryId, catRow.id));
  }

  if (brand) conditions.push(eq(products.brand, brand));
  if (excludeId) conditions.push(ne(products.id, parseInt(excludeId, 10)));
  if (featured) conditions.push(eq(products.isFeatured, true));
  if (minPrice) conditions.push(gte(products.price, minPrice));
  if (maxPrice) conditions.push(lte(products.price, maxPrice));
  if (q) {
    conditions.push(
      or(
        ilike(products.name, `%${q}%`),
        ilike(products.brand, `%${q}%`),
        ilike(products.shortDescription, `%${q}%`),
      )!,
    );
  }

  let orderBy;
  switch (sort) {
    case "price_asc":
      orderBy = asc(products.price);
      break;
    case "price_desc":
      orderBy = desc(products.price);
      break;
    case "newest":
      orderBy = desc(products.createdAt);
      break;
    case "rating":
      orderBy = desc(products.rating);
      break;
    case "bestseller":
      orderBy = desc(products.soldCount);
      break;
    default:
      orderBy = desc(products.isFeatured);
  }

  const rows = await db
    .select({
      id: products.id,
      name: products.name,
      slug: products.slug,
      brand: products.brand,
      shortDescription: products.shortDescription,
      images: products.images,
      price: products.price,
      compareAtPrice: products.compareAtPrice,
      stock: products.stock,
      rating: products.rating,
      reviewCount: products.reviewCount,
      soldCount: products.soldCount,
      isFeatured: products.isFeatured,
      tags: products.tags,
      categoryId: products.categoryId,
      categoryName: categories.name,
      categorySlug: categories.slug,
      vendorName: vendors.name,
      vendorId: vendors.id,
      createdAt: products.createdAt,
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .leftJoin(vendors, eq(products.vendorId, vendors.id))
    .where(and(...conditions))
    .orderBy(orderBy, desc(products.soldCount))
    .limit(limit + 1)
    .offset(page * limit);

  const hasMore = rows.length > limit;
  const items = hasMore ? rows.slice(0, limit) : rows;

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products)
    .where(and(...conditions));

  return NextResponse.json({
    products: items,
    hasMore,
    nextPage: page + 1,
    total: count,
  });
}
