import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { getAdminSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await getAdminSession();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const body = await req.json();

  const [product] = await db
    .update(products)
    .set({
      vendorId: body.vendorId,
      categoryId: body.categoryId,
      name: body.name,
      brand: body.brand,
      shortDescription: body.shortDescription,
      description: body.description,
      specs: body.specs || {},
      images: body.images || [],
      price: String(body.price),
      compareAtPrice: body.compareAtPrice ? String(body.compareAtPrice) : null,
      stock: Number(body.stock) || 0,
      tags: body.tags || [],
      status: body.status,
      isFeatured: !!body.isFeatured,
    })
    .where(eq(products.id, parseInt(id, 10)))
    .returning();

  return NextResponse.json({ product });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await getAdminSession();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  await db.delete(products).where(eq(products.id, parseInt(id, 10)));
  return NextResponse.json({ ok: true });
}
