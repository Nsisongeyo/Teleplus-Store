import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { getAdminSession } from "@/lib/auth";
import { slugify } from "@/lib/format";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  const admin = await getAdminSession();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const baseSlug = slugify(body.name);
  let slug = baseSlug;
  let i = 1;
  while ((await db.select().from(products).where(eq(products.slug, slug)).limit(1)).length) {
    slug = `${baseSlug}-${i++}`;
  }

  const [product] = await db
    .insert(products)
    .values({
      vendorId: body.vendorId,
      categoryId: body.categoryId,
      name: body.name,
      slug,
      brand: body.brand,
      shortDescription: body.shortDescription,
      description: body.description,
      specs: body.specs || {},
      images: body.images || [],
      price: String(body.price),
      compareAtPrice: body.compareAtPrice ? String(body.compareAtPrice) : null,
      stock: Number(body.stock) || 0,
      tags: body.tags || [],
      status: body.status || "live",
      isFeatured: !!body.isFeatured,
    })
    .returning();

  return NextResponse.json({ product });
}
