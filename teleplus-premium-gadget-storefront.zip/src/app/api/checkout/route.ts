import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, products, vendors } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const {
    customerName,
    customerPhone,
    customerEmail,
    address,
    city,
    note,
    paymentMethod,
    items,
  } = body as {
    customerName: string;
    customerPhone: string;
    customerEmail?: string;
    address: string;
    city?: string;
    note?: string;
    paymentMethod: string;
    items: { productId: number; qty: number }[];
  };

  if (!customerName?.trim() || !customerPhone?.trim() || !address?.trim() || !items?.length) {
    return NextResponse.json({ error: "Missing required checkout fields" }, { status: 400 });
  }

  const productIds = items.map((i) => i.productId);
  const dbProducts = await db
    .select({
      id: products.id,
      name: products.name,
      images: products.images,
      price: products.price,
      vendorId: products.vendorId,
      vendorName: vendors.name,
      stock: products.stock,
    })
    .from(products)
    .leftJoin(vendors, eq(products.vendorId, vendors.id))
    .where(inArray(products.id, productIds));

  if (!dbProducts.length) {
    return NextResponse.json({ error: "Products not found" }, { status: 400 });
  }

  const orderItems = items
    .map((item) => {
      const p = dbProducts.find((dp) => dp.id === item.productId);
      if (!p) return null;
      return {
        productId: p.id,
        name: p.name,
        image: p.images?.[0] || "",
        price: Number(p.price),
        qty: item.qty,
        vendorId: p.vendorId,
        vendorName: p.vendorName || "Teleplus Store",
      };
    })
    .filter(Boolean) as {
    productId: number;
    name: string;
    image: string;
    price: number;
    qty: number;
    vendorId: number;
    vendorName: string;
  }[];

  const subtotal = orderItems.reduce((sum, i) => sum + i.price * i.qty, 0);
  const shippingFee = subtotal >= 500000 || subtotal === 0 ? 0 : 3500;
  const total = subtotal + shippingFee;
  const orderNumber = `TP-${Date.now().toString(36).toUpperCase()}`;

  const [order] = await db
    .insert(orders)
    .values({
      orderNumber,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail?.trim() || null,
      address: address.trim(),
      city: city?.trim() || null,
      note: note?.trim() || null,
      items: orderItems,
      subtotal: subtotal.toString(),
      shippingFee: shippingFee.toString(),
      total: total.toString(),
      paymentMethod: paymentMethod || "pay_on_delivery",
      status: "pending",
    })
    .returning();

  return NextResponse.json({ orderNumber: order.orderNumber, order });
}
