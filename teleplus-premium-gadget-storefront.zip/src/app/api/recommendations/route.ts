import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products, interactions, categories, vendors } from "@/db/schema";
import { and, desc, eq, inArray, notInArray, or, sql } from "drizzle-orm";

type Row = {
  id: number;
  name: string;
  slug: string;
  brand: string;
  images: string[] | null;
  price: string;
  compareAtPrice: string | null;
  rating: string | null;
  reviewCount: number;
  soldCount: number;
  categoryName: string | null;
  vendorName: string | null;
};

export async function GET(req: NextRequest) {
  const visitorId = req.nextUrl.searchParams.get("visitorId");
  const limit = Math.min(parseInt(req.nextUrl.searchParams.get("limit") || "8", 10), 20);

  let topCategoryIds: number[] = [];
  let topBrands: string[] = [];

  if (visitorId) {
    const catRows = await db
      .select({ categoryId: interactions.categoryId, weight: sql<number>`count(*)::int` })
      .from(interactions)
      .where(and(eq(interactions.visitorId, visitorId), sql`${interactions.categoryId} is not null`))
      .groupBy(interactions.categoryId)
      .orderBy(desc(sql`count(*)`))
      .limit(3);
    topCategoryIds = catRows.map((r) => r.categoryId!).filter(Boolean);

    const brandRows = await db
      .select({ brand: interactions.brand, weight: sql<number>`count(*)::int` })
      .from(interactions)
      .where(and(eq(interactions.visitorId, visitorId), sql`${interactions.brand} is not null`))
      .groupBy(interactions.brand)
      .orderBy(desc(sql`count(*)`))
      .limit(3);
    topBrands = brandRows.map((r) => r.brand!).filter(Boolean);
  }

  const baseSelect = {
    id: products.id,
    name: products.name,
    slug: products.slug,
    brand: products.brand,
    images: products.images,
    price: products.price,
    compareAtPrice: products.compareAtPrice,
    rating: products.rating,
    reviewCount: products.reviewCount,
    soldCount: products.soldCount,
    categoryName: categories.name,
    vendorName: vendors.name,
  };

  let personalized: Row[] = [];

  if (topCategoryIds.length || topBrands.length) {
    const matchers = [];
    if (topCategoryIds.length) matchers.push(inArray(products.categoryId, topCategoryIds));
    if (topBrands.length) matchers.push(inArray(products.brand, topBrands));

    personalized = (await db
      .select(baseSelect)
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .leftJoin(vendors, eq(products.vendorId, vendors.id))
      .where(and(eq(products.status, "live"), or(...matchers)))
      .orderBy(desc(products.rating), desc(products.soldCount))
      .limit(limit)) as Row[];
  }

  let result: Row[] = personalized;
  const isPersonalized = personalized.length > 0;

  if (result.length < limit) {
    const excludeIds = result.map((r) => r.id);
    const trending = (await db
      .select(baseSelect)
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .leftJoin(vendors, eq(products.vendorId, vendors.id))
      .where(
        excludeIds.length
          ? and(eq(products.status, "live"), notInArray(products.id, excludeIds))
          : eq(products.status, "live"),
      )
      .orderBy(desc(products.soldCount), desc(products.rating))
      .limit(limit - result.length)) as Row[];
    result = [...result, ...trending];
  }

  return NextResponse.json({ products: result, personalized: isPersonalized });
}
