import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { interactions, products } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { visitorId, action, productId, categoryId, brand } = body as {
      visitorId?: string;
      action?: string;
      productId?: number;
      categoryId?: number;
      brand?: string;
    };

    if (!visitorId || !action) {
      return NextResponse.json({ ok: false }, { status: 400 });
    }

    let resolvedCategoryId = categoryId ?? null;
    let resolvedBrand = brand ?? null;

    if (productId && (!resolvedCategoryId || !resolvedBrand)) {
      const [p] = await db
        .select({ categoryId: products.categoryId, brand: products.brand })
        .from(products)
        .where(eq(products.id, productId))
        .limit(1);
      if (p) {
        resolvedCategoryId = resolvedCategoryId ?? p.categoryId;
        resolvedBrand = resolvedBrand ?? p.brand;
      }
    }

    await db.insert(interactions).values({
      visitorId,
      productId: productId ?? null,
      categoryId: resolvedCategoryId,
      brand: resolvedBrand,
      action,
    });

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false }, { status: 200 });
  }
}
