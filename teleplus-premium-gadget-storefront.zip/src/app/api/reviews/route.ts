import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { productId, authorName, rating, title, body: reviewBody } = body as {
    productId: number;
    authorName: string;
    rating: number;
    title?: string;
    body?: string;
  };

  if (!productId || !authorName?.trim() || !rating) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  const [review] = await db
    .insert(reviews)
    .values({
      productId,
      authorName: authorName.trim().slice(0, 60),
      rating: Math.min(5, Math.max(1, Math.round(rating))),
      title: title?.trim().slice(0, 120) || null,
      body: reviewBody?.trim().slice(0, 2000) || null,
      verified: false,
    })
    .returning();

  const agg = await db
    .select({
      avg: sql<string>`avg(${reviews.rating})`,
      count: sql<number>`count(*)::int`,
    })
    .from(reviews)
    .where(eq(reviews.productId, productId));

  await db
    .update(products)
    .set({
      rating: Number(agg[0].avg).toFixed(2),
      reviewCount: agg[0].count,
    })
    .where(eq(products.id, productId));

  return NextResponse.json({ review });
}
