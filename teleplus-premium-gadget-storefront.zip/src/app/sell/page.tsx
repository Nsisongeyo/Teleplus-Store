"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Rocket, TrendingUp, ShieldCheck, Users } from "lucide-react";

const PERKS = [
  { icon: Users, title: "Reach thousands of buyers", desc: "Tap into a growing community of gadget lovers actively shopping every day." },
  { icon: TrendingUp, title: "Smart product discovery", desc: "Our recommendation engine surfaces your products to the shoppers most likely to buy." },
  { icon: ShieldCheck, title: "Secure & trusted", desc: "Every vendor is verified before their storefront goes live to keep buyers confident." },
  { icon: Rocket, title: "Fast onboarding", desc: "List your first product in minutes — no setup fees, no hidden charges." },
];

export default function SellPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "", phone: "", description: "" });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/vendor/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong");
      router.push("/vendor");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 gap-14 lg:grid-cols-2">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#1881a2]">Teleplus Marketplace</p>
          <h1 className="mt-2 font-display text-3xl font-bold text-slate-900 sm:text-4xl">
            Sell your gadgets to thousands of buyers
          </h1>
          <p className="mt-4 text-slate-500">
            Join the Teleplus marketplace and list your laptops, phones and accessories alongside our official
            catalog. Apply below — approval usually takes less than a day.
          </p>

          <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2">
            {PERKS.map((perk) => (
              <div key={perk.title} className="rounded-2xl border border-slate-200 p-5">
                <perk.icon className="h-6 w-6 text-[#1881a2]" />
                <p className="mt-3 font-display text-sm font-bold text-slate-900">{perk.title}</p>
                <p className="mt-1 text-xs text-slate-500">{perk.desc}</p>
              </div>
            ))}
          </div>

          <p className="mt-8 text-sm text-slate-500">
            Already a vendor?{" "}
            <Link href="/vendor/login" className="font-semibold text-[#1881a2]">
              Log in to your dashboard
            </Link>
          </p>
        </div>

        <form onSubmit={handleSubmit} className="flex h-fit flex-col gap-4 rounded-3xl border border-slate-200 p-7">
          <h2 className="font-display text-lg font-bold text-slate-900">Apply to sell</h2>
          <input
            required
            placeholder="Business / Store name"
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
          />
          <input
            required
            type="email"
            placeholder="Email address"
            value={form.email}
            onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
          />
          <input
            required
            placeholder="Phone number"
            value={form.phone}
            onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
          />
          <input
            required
            type="password"
            placeholder="Create a password"
            value={form.password}
            onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
          />
          <textarea
            placeholder="Tell us what you sell"
            rows={3}
            value={form.description}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
          />
          {error && <p className="text-sm font-medium text-red-500">{error}</p>}
          <button
            disabled={submitting}
            className="rounded-full bg-[#1881a2] py-3.5 text-sm font-semibold text-white transition hover:bg-[#106680] disabled:opacity-50"
          >
            {submitting ? "Submitting..." : "Apply Now"}
          </button>
          <p className="text-center text-xs text-slate-400">
            By applying you agree to Teleplus Marketplace seller terms.
          </p>
        </form>
      </div>
    </main>
  );
}
