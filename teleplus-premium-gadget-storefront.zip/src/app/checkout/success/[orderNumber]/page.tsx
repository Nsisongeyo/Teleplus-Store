import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { CheckCircle2, MessageCircle } from "lucide-react";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { formatNaira } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function OrderSuccessPage({ params }: { params: Promise<{ orderNumber: string }> }) {
  const { orderNumber } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  if (!order) notFound();

  const whatsappMessage = `Hi Teleplus Store, I just placed order ${order.orderNumber} totalling ${formatNaira(
    Number(order.total),
  )}. Please confirm my order.`;
  const whatsappLink = `https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <main className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
      <div className="flex flex-col items-center gap-3 text-center">
        <div className="grid h-16 w-16 place-items-center rounded-full bg-emerald-50 text-emerald-500 animate-pop">
          <CheckCircle2 className="h-9 w-9" />
        </div>
        <h1 className="font-display text-2xl font-bold text-slate-900 sm:text-3xl">Order placed successfully!</h1>
        <p className="text-slate-500">
          Order <span className="font-semibold text-slate-800">{order.orderNumber}</span> has been received. We&apos;ll
          reach out on <span className="font-semibold text-slate-800">{order.customerPhone}</span> shortly.
        </p>
      </div>

      <div className="mt-10 rounded-3xl border border-slate-200 p-6">
        <h2 className="mb-4 font-display text-base font-bold text-slate-900">Order Details</h2>
        <ul className="flex flex-col divide-y divide-slate-100">
          {(order.items || []).map((item) => (
            <li key={item.productId} className="flex items-center gap-4 py-3">
              <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                <Image src={item.image} alt={item.name} fill className="object-cover" sizes="56px" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-800">{item.name}</p>
                <p className="text-xs text-slate-400">
                  Qty {item.qty} × {formatNaira(item.price)}
                </p>
              </div>
              <p className="text-sm font-semibold text-slate-900">{formatNaira(item.price * item.qty)}</p>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex flex-col gap-2 border-t border-slate-100 pt-4 text-sm">
          <div className="flex justify-between text-slate-500">
            <span>Subtotal</span>
            <span>{formatNaira(Number(order.subtotal))}</span>
          </div>
          <div className="flex justify-between text-slate-500">
            <span>Shipping</span>
            <span>{Number(order.shippingFee) === 0 ? "Free" : formatNaira(Number(order.shippingFee))}</span>
          </div>
          <div className="flex justify-between border-t border-slate-100 pt-2 font-display text-base font-bold text-slate-900">
            <span>Total</span>
            <span>{formatNaira(Number(order.total))}</span>
          </div>
        </div>
      </div>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <a
          href={whatsappLink}
          target="_blank"
          rel="noreferrer"
          className="flex flex-1 items-center justify-center gap-2 rounded-full bg-[#25D366] py-3.5 text-sm font-semibold text-white transition hover:brightness-95"
        >
          <MessageCircle className="h-4 w-4" /> Confirm on WhatsApp
        </a>
        <Link
          href="/"
          className="flex flex-1 items-center justify-center rounded-full border-2 border-slate-200 py-3.5 text-sm font-semibold text-slate-700 transition hover:border-slate-300"
        >
          Continue Shopping
        </Link>
      </div>
    </main>
  );
}
