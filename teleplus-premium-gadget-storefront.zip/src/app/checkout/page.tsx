"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Truck, Wallet, MessageCircle } from "lucide-react";
import { useCartStore } from "@/store/cart";
import { formatNaira } from "@/lib/format";

const PAYMENT_METHODS = [
  { value: "pay_on_delivery", label: "Pay on Delivery", icon: Truck, desc: "Pay cash or transfer when your order arrives" },
  { value: "bank_transfer", label: "Bank Transfer", icon: Wallet, desc: "We'll send account details after you order" },
  { value: "whatsapp", label: "Confirm via WhatsApp", icon: MessageCircle, desc: "Our team will reach out to finalize payment" },
];

export default function CheckoutPage() {
  const items = useCartStore((s) => s.items);
  const subtotal = useCartStore((s) => s.subtotal());
  const clear = useCartStore((s) => s.clear);
  const router = useRouter();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    address: "",
    city: "",
    note: "",
    paymentMethod: "pay_on_delivery",
  });

  const shipping = subtotal >= 500000 || subtotal === 0 ? 0 : 3500;
  const total = subtotal + shipping;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!items.length) {
      setError("Your cart is empty.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items: items.map((i) => ({ productId: i.productId, qty: i.qty })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong");
      clear();
      router.push(`/checkout/success/${data.orderNumber}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  if (items.length === 0) {
    return (
      <main className="mx-auto flex max-w-2xl flex-col items-center gap-4 px-6 py-24 text-center">
        <h1 className="font-display text-2xl font-bold text-slate-900">Your bag is empty</h1>
        <p className="text-slate-500">Add a few products before checking out.</p>
        <Link href="/" className="rounded-full bg-[#1881a2] px-6 py-3 text-sm font-semibold text-white">
          Continue shopping
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <Link href="/" className="mb-6 flex w-fit items-center gap-1.5 text-sm text-slate-500 hover:text-slate-800">
        <ArrowLeft className="h-4 w-4" /> Back to shop
      </Link>
      <h1 className="mb-8 font-display text-2xl font-bold text-slate-900 sm:text-3xl">Checkout</h1>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">
        <form onSubmit={handleSubmit} className="flex flex-col gap-6 lg:col-span-2">
          <section className="rounded-3xl border border-slate-200 p-6">
            <h2 className="mb-4 font-display text-base font-bold text-slate-900">Contact &amp; Delivery</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <input
                required
                placeholder="Full name"
                value={form.customerName}
                onChange={(e) => setForm((f) => ({ ...f, customerName: e.target.value }))}
                className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
              />
              <input
                required
                placeholder="Phone number"
                value={form.customerPhone}
                onChange={(e) => setForm((f) => ({ ...f, customerPhone: e.target.value }))}
                className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
              />
              <input
                type="email"
                placeholder="Email (optional)"
                value={form.customerEmail}
                onChange={(e) => setForm((f) => ({ ...f, customerEmail: e.target.value }))}
                className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2] sm:col-span-2"
              />
              <input
                required
                placeholder="Delivery address"
                value={form.address}
                onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))}
                className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2] sm:col-span-2"
              />
              <input
                placeholder="City"
                value={form.city}
                onChange={(e) => setForm((f) => ({ ...f, city: e.target.value }))}
                className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
              />
              <input
                placeholder="Order note (optional)"
                value={form.note}
                onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))}
                className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
              />
            </div>
          </section>

          <section className="rounded-3xl border border-slate-200 p-6">
            <h2 className="mb-4 font-display text-base font-bold text-slate-900">Payment Method</h2>
            <div className="flex flex-col gap-3">
              {PAYMENT_METHODS.map((method) => (
                <label
                  key={method.value}
                  className={`flex cursor-pointer items-start gap-3 rounded-2xl border p-4 transition ${
                    form.paymentMethod === method.value
                      ? "border-[#1881a2] bg-[#1881a2]/5"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value={method.value}
                    checked={form.paymentMethod === method.value}
                    onChange={() => setForm((f) => ({ ...f, paymentMethod: method.value }))}
                    className="mt-1 accent-[#1881a2]"
                  />
                  <method.icon className="mt-0.5 h-5 w-5 text-[#1881a2]" />
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{method.label}</p>
                    <p className="text-xs text-slate-500">{method.desc}</p>
                  </div>
                </label>
              ))}
            </div>
          </section>

          {error && <p className="text-sm font-medium text-red-500">{error}</p>}

          <button
            disabled={submitting}
            className="rounded-full bg-[#1881a2] py-4 text-sm font-semibold text-white transition hover:bg-[#106680] disabled:opacity-50"
          >
            {submitting ? "Placing order..." : `Place Order — ${formatNaira(total)}`}
          </button>
        </form>

        <aside className="h-fit rounded-3xl border border-slate-200 p-6">
          <h2 className="mb-4 font-display text-base font-bold text-slate-900">Order Summary</h2>
          <ul className="flex flex-col gap-4">
            {items.map((item) => (
              <li key={item.productId} className="flex gap-3">
                <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                  <Image src={item.image} alt={item.name} fill className="object-cover" sizes="64px" />
                  <span className="absolute -right-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full bg-slate-900 text-[10px] font-bold text-white">
                    {item.qty}
                  </span>
                </div>
                <div className="flex-1">
                  <p className="line-clamp-2 text-xs font-medium text-slate-700">{item.name}</p>
                  <p className="mt-1 text-sm font-semibold text-slate-900">{formatNaira(item.price * item.qty)}</p>
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-5 flex flex-col gap-2 border-t border-slate-100 pt-4 text-sm">
            <div className="flex justify-between text-slate-500">
              <span>Subtotal</span>
              <span>{formatNaira(subtotal)}</span>
            </div>
            <div className="flex justify-between text-slate-500">
              <span>Shipping</span>
              <span>{shipping === 0 ? "Free" : formatNaira(shipping)}</span>
            </div>
            <div className="flex justify-between border-t border-slate-100 pt-2 font-display text-base font-bold text-slate-900">
              <span>Total</span>
              <span>{formatNaira(total)}</span>
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}
