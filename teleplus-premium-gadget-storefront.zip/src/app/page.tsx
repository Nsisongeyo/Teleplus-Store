import { Suspense } from "react";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { asc } from "drizzle-orm";
import LeftSidebar from "@/components/shop/left-sidebar";
import RightSidebar from "@/components/shop/right-sidebar";
import ProductFeed from "@/components/shop/product-feed";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const cats = await db.select().from(categories).orderBy(asc(categories.sortOrder));

  return (
    <main className="mx-auto max-w-[1600px] lg:h-[calc(100dvh-4rem)] lg:overflow-hidden">
      <div className="grid grid-cols-1 lg:h-full lg:grid-cols-[240px_minmax(0,1fr)_300px] xl:grid-cols-[260px_minmax(0,1fr)_320px]">
        <aside className="hidden border-r border-slate-200/70 lg:block lg:h-full lg:overflow-y-auto side-scroll">
          <LeftSidebar categories={cats} />
        </aside>

        <section className="lg:h-full lg:overflow-y-auto side-scroll">
          <Suspense>
            <ProductFeed />
          </Suspense>
        </section>

        <aside className="hidden border-l border-slate-200/70 lg:block lg:h-full lg:overflow-y-auto side-scroll">
          <RightSidebar />
        </aside>
      </div>
    </main>
  );
}
