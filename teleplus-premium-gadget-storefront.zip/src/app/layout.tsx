import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Suspense } from "react";
import { Inter, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import SiteHeader from "@/components/site-header";
import CartDrawer from "@/components/cart-drawer";
import Providers from "@/components/providers";

const sans = Inter({ subsets: ["latin"], variable: "--font-sans" });
const display = Plus_Jakarta_Sans({ subsets: ["latin"], variable: "--font-display" });

export const metadata: Metadata = {
  title: "Teleplus Store — Laptops, Phones & Accessories",
  description:
    "Teleplus Store — the premium marketplace for laptops, phones and gadget accessories. Shop flagship devices, order instantly on WhatsApp, and enjoy fast delivery.",
  metadataBase: new URL("https://teleplus.store"),
  openGraph: {
    title: "Teleplus Store",
    description: "Premium laptops, phones & accessories for every gadget lover.",
    images: ["/images/hero-devices.jpg"],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${sans.variable} ${display.variable}`}>
      <body className="bg-[#f5f7f8] text-[#0b1520] antialiased">
        <Providers>
          <Suspense fallback={null}>
            <SiteHeader />
          </Suspense>
          {children}
          <CartDrawer />
        </Providers>
      </body>
    </html>
  );
}
