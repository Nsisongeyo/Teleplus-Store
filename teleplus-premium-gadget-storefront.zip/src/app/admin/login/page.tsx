"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ShieldCheck } from "lucide-react";

export default function AdminLoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: "admin@teleplus.store", password: "" });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      router.push("/admin");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="grid min-h-dvh place-items-center bg-slate-950 px-4">
      <div className="w-full max-w-sm rounded-3xl bg-white p-8 shadow-2xl">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#1881a2] text-white">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h1 className="font-display text-xl font-bold text-slate-900">Teleplus Admin</h1>
          <p className="text-sm text-slate-500">Sign in to manage the store</p>
        </div>
        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          <input
            required
            type="email"
            placeholder="Email"
            value={form.email}
            onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
          />
          <input
            required
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
            className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#1881a2]"
          />
          {error && <p className="text-sm font-medium text-red-500">{error}</p>}
          <button
            disabled={submitting}
            className="mt-2 rounded-full bg-[#1881a2] py-3.5 text-sm font-semibold text-white transition hover:bg-[#106680] disabled:opacity-50"
          >
            {submitting ? "Signing in..." : "Sign in"}
          </button>
        </form>
        <p className="mt-5 rounded-xl bg-slate-50 p-3 text-center text-xs text-slate-400">
          Demo credentials: admin@teleplus.store / Teleplus@2026
        </p>
        <Link href="/" className="mt-4 block text-center text-xs text-slate-400 hover:text-slate-600">
          ← Back to store
        </Link>
      </div>
    </main>
  );
}
