import Link from "next/link";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc } from "drizzle-orm";
import { formatNaira, timeAgo } from "@/lib/format";

export const dynamic = "force-dynamic";

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-amber-100 text-amber-700",
  confirmed: "bg-blue-100 text-blue-700",
  shipped: "bg-indigo-100 text-indigo-700",
  delivered: "bg-emerald-100 text-emerald-700",
  cancelled: "bg-red-100 text-red-700",
};

export default async function AdminOrdersPage() {
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));

  return (
    <main className="px-6 py-8 sm:px-10">
      <h1 className="font-display text-2xl font-bold text-slate-900">Orders</h1>
      <p className="mt-1 text-sm text-slate-500">{rows.length} orders received</p>

      <div className="mt-6 overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
              <th className="px-5 py-3">Order</th>
              <th className="px-5 py-3">Customer</th>
              <th className="px-5 py-3">Items</th>
              <th className="px-5 py-3">Total</th>
              <th className="px-5 py-3">Status</th>
              <th className="px-5 py-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((order) => (
              <tr key={order.id} className="border-b border-slate-50 last:border-0">
                <td className="px-5 py-3">
                  <Link href={`/admin/orders/${order.id}`} className="font-semibold text-[#1881a2]">
                    {order.orderNumber}
                  </Link>
                </td>
                <td className="px-5 py-3">
                  <p className="font-medium text-slate-800">{order.customerName}</p>
                  <p className="text-xs text-slate-400">{order.customerPhone}</p>
                </td>
                <td className="px-5 py-3 text-slate-500">{(order.items || []).length} item(s)</td>
                <td className="px-5 py-3 font-medium text-slate-900">{formatNaira(Number(order.total))}</td>
                <td className="px-5 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium capitalize ${STATUS_STYLES[order.status]}`}>
                    {order.status}
                  </span>
                </td>
                <td className="px-5 py-3 text-slate-400">{timeAgo(order.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && <p className="py-16 text-center text-sm text-slate-400">No orders yet.</p>}
      </div>
    </main>
  );
}
