import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { formatNaira, timeAgo } from "@/lib/format";
import OrderStatusSelect from "@/components/admin/order-status-select";

export const dynamic = "force-dynamic";

export default async function AdminOrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.id, parseInt(id, 10))).limit(1);
  if (!order) notFound();

  return (
    <main className="px-6 py-8 sm:px-10">
      <Link href="/admin/orders" className="mb-4 flex w-fit items-center gap-1.5 text-sm text-slate-500 hover:text-slate-800">
        <ArrowLeft className="h-4 w-4" /> Back to orders
      </Link>

      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">{order.orderNumber}</h1>
          <p className="text-sm text-slate-500">Placed {timeAgo(order.createdAt)}</p>
        </div>
        <OrderStatusSelect orderId={order.id} status={order.status} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-2">
          <h2 className="mb-4 font-display text-base font-bold text-slate-900">Items</h2>
          <ul className="flex flex-col divide-y divide-slate-100">
            {(order.items || []).map((item) => (
              <li key={item.productId} className="flex items-center gap-4 py-3">
                <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                  <Image src={item.image} alt={item.name} fill className="object-cover" sizes="56px" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-800">{item.name}</p>
                  <p className="text-xs text-slate-400">
                    {item.vendorName} · Qty {item.qty} × {formatNaira(item.price)}
                  </p>
                </div>
                <p className="text-sm font-semibold text-slate-900">{formatNaira(item.price * item.qty)}</p>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex flex-col gap-2 border-t border-slate-100 pt-4 text-sm">
            <div className="flex justify-between text-slate-500">
              <span>Subtotal</span>
              <span>{formatNaira(Number(order.subtotal))}</span>
            </div>
            <div className="flex justify-between text-slate-500">
              <span>Shipping</span>
              <span>{Number(order.shippingFee) === 0 ? "Free" : formatNaira(Number(order.shippingFee))}</span>
            </div>
            <div className="flex justify-between border-t border-slate-100 pt-2 font-display text-base font-bold text-slate-900">
              <span>Total</span>
              <span>{formatNaira(Number(order.total))}</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6">
            <h2 className="mb-3 font-display text-base font-bold text-slate-900">Customer</h2>
            <p className="text-sm text-slate-700">{order.customerName}</p>
            <p className="text-sm text-slate-500">{order.customerPhone}</p>
            {order.customerEmail && <p className="text-sm text-slate-500">{order.customerEmail}</p>}
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-6">
            <h2 className="mb-3 font-display text-base font-bold text-slate-900">Delivery</h2>
            <p className="text-sm text-slate-700">{order.address}</p>
            {order.city && <p className="text-sm text-slate-500">{order.city}</p>}
            {order.note && <p className="mt-2 text-sm italic text-slate-400">&ldquo;{order.note}&rdquo;</p>}
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-6">
            <h2 className="mb-3 font-display text-base font-bold text-slate-900">Payment</h2>
            <p className="text-sm capitalize text-slate-700">{order.paymentMethod.replace(/_/g, " ")}</p>
          </div>
        </div>
      </div>
    </main>
  );
}
