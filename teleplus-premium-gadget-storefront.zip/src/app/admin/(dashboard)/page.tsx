import Link from "next/link";
import { Package, ShoppingCart, Store, Wallet, ArrowRight } from "lucide-react";
import { db } from "@/db";
import { products, orders, vendors } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { formatNaira, timeAgo } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const [[productStats], [orderStats], [pendingVendorStats], [pendingProductStats], recentOrders] = await Promise.all([
    db.select({ count: sql<number>`count(*)::int` }).from(products),
    db
      .select({
        count: sql<number>`count(*)::int`,
        revenue: sql<string>`coalesce(sum(${orders.total}), 0)`,
      })
      .from(orders),
    db.select({ count: sql<number>`count(*)::int` }).from(vendors).where(eq(vendors.status, "pending")),
    db.select({ count: sql<number>`count(*)::int` }).from(products).where(eq(products.status, "pending")),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(6),
  ]);

  const cards = [
    { label: "Total Products", value: productStats.count, icon: Package, href: "/admin/products" },
    { label: "Total Orders", value: orderStats.count, icon: ShoppingCart, href: "/admin/orders" },
    { label: "Total Revenue", value: formatNaira(Number(orderStats.revenue)), icon: Wallet, href: "/admin/orders" },
    { label: "Pending Vendors", value: pendingVendorStats.count, icon: Store, href: "/admin/vendors" },
  ];

  return (
    <main className="px-6 py-8 sm:px-10">
      <h1 className="font-display text-2xl font-bold text-slate-900">Dashboard</h1>
      <p className="mt-1 text-sm text-slate-500">Welcome back — here&apos;s what&apos;s happening at Teleplus Store.</p>

      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((card) => (
          <Link
            key={card.label}
            href={card.href}
            className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-6 transition hover:shadow-md"
          >
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#1881a2]/10 text-[#1881a2]">
              <card.icon className="h-5 w-5" />
            </div>
            <p className="font-display text-2xl font-bold text-slate-900">{card.value}</p>
            <p className="text-sm text-slate-500">{card.label}</p>
          </Link>
        ))}
      </div>

      {pendingProductStats.count > 0 && (
        <div className="mt-6 flex items-center justify-between rounded-2xl border border-amber-200 bg-amber-50 px-6 py-4">
          <p className="text-sm font-medium text-amber-700">
            {pendingProductStats.count} vendor product(s) awaiting approval
          </p>
          <Link href="/admin/products?status=pending" className="flex items-center gap-1 text-sm font-semibold text-amber-700">
            Review now <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      )}

      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-base font-bold text-slate-900">Recent Orders</h2>
          <Link href="/admin/orders" className="text-sm font-semibold text-[#1881a2]">
            View all
          </Link>
        </div>
        {recentOrders.length === 0 ? (
          <p className="py-10 text-center text-sm text-slate-400">No orders yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                  <th className="pb-3 pr-4">Order</th>
                  <th className="pb-3 pr-4">Customer</th>
                  <th className="pb-3 pr-4">Total</th>
                  <th className="pb-3 pr-4">Status</th>
                  <th className="pb-3">Date</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order) => (
                  <tr key={order.id} className="border-b border-slate-50 last:border-0">
                    <td className="py-3 pr-4">
                      <Link href={`/admin/orders/${order.id}`} className="font-medium text-[#1881a2]">
                        {order.orderNumber}
                      </Link>
                    </td>
                    <td className="py-3 pr-4 text-slate-700">{order.customerName}</td>
                    <td className="py-3 pr-4 font-medium text-slate-900">{formatNaira(Number(order.total))}</td>
                    <td className="py-3 pr-4">
                      <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium capitalize text-slate-600">
                        {order.status}
                      </span>
                    </td>
                    <td className="py-3 text-slate-400">{timeAgo(order.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </main>
  );
}
