import Link from "next/link";
import Image from "next/image";
import { Plus } from "lucide-react";
import { db } from "@/db";
import { products, categories, vendors } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { formatNaira } from "@/lib/format";
import DeleteProductButton from "@/components/admin/delete-product-button";

export const dynamic = "force-dynamic";

const STATUS_STYLES: Record<string, string> = {
  live: "bg-emerald-100 text-emerald-700",
  pending: "bg-amber-100 text-amber-700",
  draft: "bg-slate-100 text-slate-500",
};

export default async function AdminProductsPage() {
  const rows = await db
    .select({
      id: products.id,
      name: products.name,
      images: products.images,
      price: products.price,
      stock: products.stock,
      status: products.status,
      categoryName: categories.name,
      vendorName: vendors.name,
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .leftJoin(vendors, eq(products.vendorId, vendors.id))
    .orderBy(desc(products.createdAt));

  return (
    <main className="px-6 py-8 sm:px-10">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">Products</h1>
          <p className="mt-1 text-sm text-slate-500">{rows.length} products in catalog</p>
        </div>
        <Link
          href="/admin/products/new"
          className="flex items-center gap-2 rounded-full bg-[#1881a2] px-5 py-2.5 text-sm font-semibold text-white"
        >
          <Plus className="h-4 w-4" /> Add Product
        </Link>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
              <th className="px-5 py-3">Product</th>
              <th className="px-5 py-3">Vendor</th>
              <th className="px-5 py-3">Category</th>
              <th className="px-5 py-3">Price</th>
              <th className="px-5 py-3">Stock</th>
              <th className="px-5 py-3">Status</th>
              <th className="px-5 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id} className="border-b border-slate-50 last:border-0">
                <td className="flex items-center gap-3 px-5 py-3">
                  <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                    <Image src={p.images?.[0] || "/images/hero-devices.jpg"} alt={p.name} fill className="object-cover" sizes="40px" />
                  </div>
                  <span className="line-clamp-1 font-medium text-slate-800">{p.name}</span>
                </td>
                <td className="px-5 py-3 text-slate-500">{p.vendorName}</td>
                <td className="px-5 py-3 text-slate-500">{p.categoryName}</td>
                <td className="px-5 py-3 font-medium text-slate-900">{formatNaira(Number(p.price))}</td>
                <td className="px-5 py-3 text-slate-500">{p.stock}</td>
                <td className="px-5 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium capitalize ${STATUS_STYLES[p.status]}`}>
                    {p.status}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <div className="flex justify-end gap-3">
                    <Link href={`/admin/products/${p.id}`} className="text-xs font-semibold text-[#1881a2]">
                      Edit
                    </Link>
                    <DeleteProductButton id={p.id} endpoint={`/api/admin/products/${p.id}`} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
