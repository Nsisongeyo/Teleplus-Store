import { notFound } from "next/navigation";
import { db } from "@/db";
import { products, categories, vendors } from "@/db/schema";
import { eq } from "drizzle-orm";
import ProductForm from "@/components/admin/product-form";

export const dynamic = "force-dynamic";

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [product] = await db.select().from(products).where(eq(products.id, parseInt(id, 10))).limit(1);
  if (!product) notFound();

  const [cats, vends] = await Promise.all([db.select().from(categories), db.select().from(vendors)]);

  return (
    <main className="px-6 py-8 sm:px-10">
      <h1 className="mb-6 font-display text-2xl font-bold text-slate-900">Edit Product</h1>
      <ProductForm
        categories={cats}
        vendors={vends}
        apiEndpoint={`/api/admin/products/${product.id}`}
        method="PUT"
        redirectTo="/admin/products"
        initialData={{
          name: product.name,
          brand: product.brand,
          categoryId: product.categoryId,
          vendorId: product.vendorId,
          shortDescription: product.shortDescription || "",
          description: product.description || "",
          price: product.price,
          compareAtPrice: product.compareAtPrice || "",
          stock: String(product.stock),
          status: product.status,
          isFeatured: product.isFeatured,
          images: product.images || [],
          specs: product.specs || {},
          tags: product.tags || [],
        }}
      />
    </main>
  );
}
