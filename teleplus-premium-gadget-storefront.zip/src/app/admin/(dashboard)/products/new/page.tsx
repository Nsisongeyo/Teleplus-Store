import { db } from "@/db";
import { categories, vendors } from "@/db/schema";
import ProductForm from "@/components/admin/product-form";

export const dynamic = "force-dynamic";

export default async function NewProductPage() {
  const [cats, vends] = await Promise.all([db.select().from(categories), db.select().from(vendors)]);

  return (
    <main className="px-6 py-8 sm:px-10">
      <h1 className="mb-6 font-display text-2xl font-bold text-slate-900">Add New Product</h1>
      <ProductForm
        categories={cats}
        vendors={vends}
        apiEndpoint="/api/admin/products"
        method="POST"
        redirectTo="/admin/products"
      />
    </main>
  );
}
