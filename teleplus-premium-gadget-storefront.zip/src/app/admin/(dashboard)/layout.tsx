import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { getAdminSession } from "@/lib/auth";
import AdminSidebar from "@/components/admin/sidebar";

export default async function AdminDashboardLayout({ children }: { children: ReactNode }) {
  const admin = await getAdminSession();
  if (!admin) redirect("/admin/login");

  return (
    <div className="flex min-h-dvh bg-slate-100">
      <AdminSidebar name={admin.name} />
      <div className="flex-1 overflow-x-hidden">{children}</div>
    </div>
  );
}
